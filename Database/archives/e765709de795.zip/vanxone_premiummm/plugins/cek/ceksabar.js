// cek/ceksabar — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/ceksabar.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "ceksabar",
  "command": [
    "sabar",
    "patience"
  ],
  "category": "cek",
  "desc": "Cek tingkat kesabaran kamu",
  "usage": ".ceksabar <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/ceksabar", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/ceksabar.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'ceksabar',
      alias: ['sabar', 'patience'],
      category: 'cek',
      description: 'Cek tingkat kesabaran kamu',
      usage: '.ceksabar <nama>',
      example: '.ceksabar Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) desc = 'Sabar level dewa! Zen master~ 🧘'
      else if (percent >= 70) desc = 'Sangat sabar! Terpuji 👏'
      else if (percent >= 50) desc = 'Cukup sabar 😊'
      else if (percent >= 30) desc = 'Kadang emosian dikit 😅'
      else desc = 'Gampang marah nih... 😤'
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kesabaran kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kesabaran @${mentioned.split('@')[0]} yak? 
      
  Tingkat kesabaran dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
