// cecan/papayang — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/papayang.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "papayang",
  "command": [
    "papayang",
    "papdoi"
  ],
  "category": "asupan",
  "desc": "Perintah papayang",
  "usage": "",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __vx.plugin("cecan/papayang", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/papayang.js'
  const __vxExports = {};
  const handler = async (m, { sock }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => null);
  
  	try {
  		const buffer = await global.fetchApi('kyzz', '/api/image/papayang', {}, {
  			responseType: 'arraybuffer',
  			headers: {
  				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
  			}
  		});
  
  		await sock.sendMessage(m.chat, { react: { text: '📱', key: m.key } }).catch(() => null);
  
  		const caption = `📱 *PAP AYANG*\n\n© ${global.namaBot}`;
  
  		return await sock.sendMessage(m.chat, {
  			image: Buffer.from(buffer),
  			caption: caption
  		}, { quoted: m });
  
  	} catch (e) {
  		console.error('[PAPAYANG ERROR]:', e.message);
  		await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => null);
  		return m.reply('❌ Gagal mengambil gambar Pap Ayang.');
  	}
  };
  
  handler.command = ['papayang', 'papdoi'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
