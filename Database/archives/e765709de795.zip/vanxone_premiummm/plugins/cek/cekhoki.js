// cek/cekhoki — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekhoki.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekhoki",
  "command": [
    "hoki",
    "lucky"
  ],
  "category": "cek",
  "desc": "Cek seberapa hoki kamu",
  "usage": ".cekhoki <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekhoki", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekhoki.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekhoki',
      alias: ['hoki', 'lucky'],
      category: 'cek',
      description: 'Cek seberapa hoki kamu',
      usage: '.cekhoki <nama>',
      example: '.cekhoki Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'HOKI DEWA! Main gacha pasti menang! 🍀✨'
      } else if (percent >= 70) {
          desc = 'Hoki banget! 🎰'
      } else if (percent >= 50) {
          desc = 'Lumayan hoki 🍀'
      } else if (percent >= 30) {
          desc = 'Sedikit hoki 😊'
      } else {
          desc = 'Sabar ya, lagi apes 😅'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kehokian kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kehokian @${mentioned.split('@')[0]} yak? 
      
  Tingkat kehokian dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
