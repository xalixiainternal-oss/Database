// fitur tambahan × - vanXone </> (cek/cekpinter)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpinter", {"command":["cekpinter"],"category":"cek","desc":"Fitur cekpinter [@user]","usage":".cekpinter"})
