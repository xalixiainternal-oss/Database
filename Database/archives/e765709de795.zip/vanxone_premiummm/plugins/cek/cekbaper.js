// fitur tambahan × - vanXone </> (cek/cekbaper)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbaper", {"command":["cekbaper"],"category":"cek","desc":"Fitur cekbaper [@user]","usage":".cekbaper"})
