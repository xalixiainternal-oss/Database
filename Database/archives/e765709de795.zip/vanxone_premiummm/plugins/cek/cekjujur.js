// fitur tambahan × - vanXone </> (cek/cekjujur)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjujur", {"command":["cekjujur"],"category":"cek","desc":"Fitur cekjujur [@user]","usage":".cekjujur"})
