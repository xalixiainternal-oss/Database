// fitur tambahan × - vanXone </> (cek/cekbau)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbau", {"command":["cekbau"],"category":"cek","desc":"Fitur cekbau [@user]","usage":".cekbau"})
