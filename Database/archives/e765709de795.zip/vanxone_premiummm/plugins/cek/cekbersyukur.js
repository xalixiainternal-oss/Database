// fitur tambahan × - vanXone </> (cek/cekbersyukur)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbersyukur", {"command":["cekbersyukur"],"category":"cek","desc":"Fitur cekbersyukur [@user]","usage":".cekbersyukur"})
