// fitur tambahan × - vanXone </> (ai/qwerty-vanxone)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/qwerty-vanxone", {"command":["qwerty"],"category":"ai","desc":"Fitur qwerty","usage":".qwerty"})
