// fitur tambahan × - vanXone </> (cek/cekramah)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekramah", {"command":["cekramah"],"category":"cek","desc":"Fitur cekramah [@user]","usage":".cekramah"})
