// fitur tambahan × - vanXone </> (audio/distortion)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/distortion", {"command":["distortion"],"category":"audio","desc":"Fitur distortion","usage":".distortion"})
