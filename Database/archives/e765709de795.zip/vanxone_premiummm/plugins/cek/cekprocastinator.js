// fitur tambahan × - vanXone </> (cek/cekprocastinator)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekprocastinator", {"command":["cekprocastinator","procrastinator","nunda"],"category":"cek","desc":"Cek tingkat suka menunda","usage":".cekprocastinator"})
