// fitur tambahan × - vanXone </> (cek/cekkejam)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkejam", {"command":["cekkejam"],"category":"cek","desc":"Fitur cekkejam [@user]","usage":".cekkejam"})
