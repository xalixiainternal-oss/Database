// cek/cekpintar — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekpintar.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekpintar",
  "command": [
    "pintar",
    "iq",
    "smart"
  ],
  "category": "cek",
  "desc": "Cek seberapa pintar kamu",
  "usage": ".cekpintar <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekpintar", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekpintar.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekpintar',
      alias: ['pintar', 'iq', 'smart'],
      category: 'cek',
      description: 'Cek seberapa pintar kamu',
      usage: '.cekpintar <nama>',
      example: '.cekpintar Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const mentioned = m.mentionedJid[0] || m.sender
  
          const iq = Math.floor(Math.random() * 100) + 70
      
      let desc = ''
      if (iq >= 150) {
          desc = 'JENIUS! Einstein level! 🧠✨'
      } else if (iq >= 130) {
          desc = 'Sangat cerdas! 🎓'
      } else if (iq >= 110) {
          desc = 'Di atas rata-rata! 👍'
      } else if (iq >= 90) {
          desc = 'Normal, rata-rata 😊'
      } else {
          desc = 'Tetap semangat belajar! 📚'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Kepintaran (IQ) kamu *${iq}*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek kepintaran @${mentioned.split('@')[0]} yak? 
      
  Kepintaran (IQ) dia sebesar *${iq}*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
