// fitur tambahan × - vanXone </> (ai/gemini-vanxone)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/gemini-vanxone", {"command":["vanxone"],"category":"ai","desc":"Fitur vanxone","usage":".vanxone"})
