// fitur tambahan × - vanXone </> (cek/cekrezeki)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekrezeki", {"command":["cekrezeki","rezeki","fortune"],"category":"cek","desc":"Cek tingkat rezeki kamu hari ini","usage":".cekrezeki"})
