// fitur tambahan × - vanXone </> (cek/cekplayboy)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekplayboy", {"command":["cekplayboy"],"category":"cek","desc":"Fitur cekplayboy [@user]","usage":".cekplayboy"})
