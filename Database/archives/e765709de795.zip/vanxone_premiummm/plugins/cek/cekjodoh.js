// fitur tambahan × - vanXone </> (cek/cekjodoh)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjodoh", {"command":["cekjodoh","match"],"category":"cek","desc":"Cek kecocokan jodoh","usage":".cekjodoh"})
