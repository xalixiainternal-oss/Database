// fitur tambahan × - vanXone </> (cek/cekrakus)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekrakus", {"command":["cekrakus"],"category":"cek","desc":"Fitur cekrakus [@user]","usage":".cekrakus"})
