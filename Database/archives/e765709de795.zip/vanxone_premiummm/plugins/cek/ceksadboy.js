// fitur tambahan × - vanXone </> (cek/ceksadboy)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceksadboy", {"command":["ceksadboy"],"category":"cek","desc":"Fitur ceksadboy [@tag/nama]","usage":".ceksadboy"})
