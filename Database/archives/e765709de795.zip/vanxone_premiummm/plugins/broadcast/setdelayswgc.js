// fitur tambahan × - vanXone </> (jpm/setdelayswgc)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/setdelayswgc", {"command":["setdelayswgc"],"category":"broadcast","desc":"Fitur setdelayswgc","usage":".setdelayswgc","owner":true})
