// fitur tambahan × - vanXone </> (cek/cekmunafik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmunafik", {"command":["cekmunafik"],"category":"cek","desc":"Fitur cekmunafik [@user]","usage":".cekmunafik"})
