// asupan/asupantiktok — satu file: metadata + kode fitur (gabungan dari engine3/plugins/asupan/asupantiktok.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "asupantiktok",
  "command": [
    "asupantiktok",
    "tiktokasupan",
    "ttasupan"
  ],
  "category": "asupan",
  "desc": "Video TikTok dari username random atau spesifik",
  "usage": ".asupantiktok [username]",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 15,
  "energi": 2,
  "needs": {
    "apikeys": [
      "neoxr"
    ],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __vx.plugin("asupan/asupantiktok", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/asupantiktok.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const axios = __vxDef(require("axios"));
  const config = __vxDef(require("../../lib/ext/config.e3.js"));
  const { f } = require("../../lib/ext/src/lib/vanxone-http.js");
  const { saluranCtx } = require("../../lib/ext/src/lib/vanxone-context.js");
  const pluginConfig = {
    name: "asupantiktok",
    alias: ["tiktokasupan", "ttasupan"],
    category: "asupan",
    description: "Video TikTok dari username random atau spesifik",
    usage: ".asupantiktok [username]",
    example: ".asupantiktok natajadeh",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 15,
    energi: 2,
    isEnabled: true,
  };
  
  const usernames = [
    "natajadeh",
    "aletaanovianda",
    "faisafch",
    "0rbby",
    "cindyanastt",
    "awaa.an",
    "nadineabgail",
    "ciloqciliq",
    "carluskiey",
    "wuxiaturuxia",
    "joomblo",
    "hxszys",
    "indomeysleramu",
    "anindthrc",
    "m1cel",
    "chrislin.chrislin",
    "brocolee__",
    "dxzdaa",
    "toodlesprunky",
    "wasawho",
    "paphricia",
    "queenzlyjlita",
    "apol1yon",
    "eliceannabella",
    "aintyrbaby",
    "christychriselle",
    "natalienovita",
    "glennvmi",
    "_rgtaaa",
    "felicialrnz",
    "zahraazzhri",
    "mdy.li",
    "jeyiiiii_",
    "bbytiffs",
    "irenefennn",
    "mellyllyyy",
    "xsta_xstar",
    "n0_0ella",
    "kutubuku6690",
    "cesiann",
    "gaby.rosse",
    "charrvm_",
    "bilacml04",
    "whosyoraa",
    "ishaangelica",
    "heresthekei",
    "gemoy.douyin",
    "nathasyaest",
    "jasmine.mat",
    "akuallyaa",
    "meycoco22",
    "baby_sya66",
    "knzymyln__",
    "rin.channn",
    "audicamy",
    "franzeskaedelyn",
    "shiraishi.ito",
    "itsceceh",
    "senpai_cj7",
  ];
  
  async function handler(m, { sock }) {
    const query =
      m.text?.trim() || usernames[Math.floor(Math.random() * usernames.length)];
  
    m.react("🕕");
  
    try {
      const { data } = await f(
        `https://api.neoxr.eu/api/asupan?username=${query}&apikey=${config.APIkey.neoxr}`,
      );
  
      if (!data) {
        m.react("❌");
        return m.reply(`🚩 *Username Tidak Ditemukan*\n\n> Username: ${query}`);
      }
  
      const video = data;
  
      m.react("✅");
  
      const videoUrl = video.video.url;
  
      await sock.sendMedia(m.chat, videoUrl, `${video.caption}`, m, {
        type: "video",
        contextInfo: saluranCtx(),
      });
    } catch (error) {
      m.react("❌");
      m.reply(`🚩 *Username Tidak Ditemukan*\n\n> Username: ${query}`);
    }
  }
  
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
