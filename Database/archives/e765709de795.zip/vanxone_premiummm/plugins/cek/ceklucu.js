// fitur tambahan × - vanXone </> (cek/ceklucu)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklucu", {"command":["ceklucu"],"category":"cek","desc":"Fitur ceklucu [@user]","usage":".ceklucu"})
