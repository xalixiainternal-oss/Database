// cecan/cewerandom — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/cewerandom.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "cewerandom",
  "command": [
    "cewerandom",
    "ceweku"
  ],
  "category": "asupan",
  "desc": "Fitur cewerandom",
  "usage": ".cewerandom",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __vx.plugin("cecan/cewerandom", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cewerandom.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const sendCecan = __vxDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const allCategories = [
  	'China', 'Hijaber', 'Indonesia', 'Japan', 'Jeni', 'Jiso',
  	'Korea', 'Justinaxie', 'Malaysia', 'Rose', 'Ryujin', 'Thailand', 'Vietnam'
  ];
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		const category = allCategories[Math.floor(Math.random() * allCategories.length)];
  		await sendCecan(sock, m, reply, category);
  	} catch (e) {
  		console.error('[CEWERANDOM ALL ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cewe random.');
  	}
  };
  
  handler.help = ['cewerandom'];
  handler.tags = ['cewerandom'];
  handler.command = ['cewerandom', 'ceweku'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
