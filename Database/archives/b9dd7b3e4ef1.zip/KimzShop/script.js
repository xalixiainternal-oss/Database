// ================== KONFIGURASI TOKO ==================
// Ganti nomor di bawah dengan nomor WhatsApp admin.
// Gunakan kode negara tanpa tanda +, spasi, atau angka 0 di depan.
// Contoh Indonesia: 6281234567890
const ADMIN_WHATSAPP = "6281234567890";

// Edit, tambah, atau hapus produk sesuai kebutuhan.
// Harga menggunakan Rupiah (angka saja).
const products = [
  { id: 1, name: "Panel Bot 1GB", category: "Panel Bot", price: 1000, emoji: "⚡", tag: "STARTER", description: "Paket panel bot 1GB." },
  { id: 2, name: "Panel Bot 2GB", category: "Panel Bot", price: 2000, emoji: "🚀", tag: "POPULER", description: "Paket panel bot 2GB." },
  { id: 3, name: "Panel Bot 3GB", category: "Panel Bot", price: 3000, emoji: "💎", tag: "VALUE", description: "Paket panel bot 3GB." },
  { id: 4, name: "Panel Bot 4GB", category: "Panel Bot", price: 4000, emoji: "🛠️", tag: "", description: "Paket panel bot 4GB." },
  { id: 5, name: "Panel Bot 5GB", category: "Panel Bot", price: 5000, emoji: "🌟", tag: "FAVORIT", description: "Paket panel bot 5GB." },
  { id: 6, name: "Panel Bot 6GB", category: "Panel Bot", price: 6000, emoji: "🧩", tag: "", description: "Paket panel bot 6GB." },
  { id: 7, name: "Panel Bot 7GB", category: "Panel Bot", price: 7000, emoji: "🔋", tag: "", description: "Paket panel bot 7GB." },
  { id: 8, name: "Panel Bot 8GB", category: "Panel Bot", price: 8000, emoji: "🎯", tag: "", description: "Paket panel bot 8GB." },
  { id: 9, name: "Panel Bot 9GB", category: "Panel Bot", price: 9000, emoji: "🛰️", tag: "", description: "Paket panel bot 9GB." },
  { id: 10, name: "Panel Bot 10GB", category: "Panel Bot", price: 10000, emoji: "👑", tag: "PRO", description: "Paket panel bot 10GB." },
  { id: 11, name: "Jasa Setup Bot", category: "Layanan", price: 15000, emoji: "🤖", tag: "LAYANAN", description: "Bantuan setup bot sesuai kebutuhan." },
  { id: 12, name: "Konsultasi Digital", category: "Digital", price: 5000, emoji: "💬", tag: "", description: "Tanya jawab kebutuhan digital." }
];
// =======================================================

const rupiah = value => new Intl.NumberFormat("id-ID", {
  style: "currency", currency: "IDR", maximumFractionDigits: 0
}).format(value);

let selectedCategory = "Semua";
let cart = {};
try { cart = JSON.parse(localStorage.getItem("kimzShopCart") || "{}"); } catch { cart = {}; }

const grid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const cartDrawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const toast = document.getElementById("toast");

function saveCart() {
  try { localStorage.setItem("kimzShopCart", JSON.stringify(cart)); } catch {}
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2100);
}
function filteredProducts() {
  const query = searchInput.value.trim().toLowerCase();
  let list = products.filter(p =>
    (selectedCategory === "Semua" || p.category === selectedCategory) &&
    (p.name.toLowerCase().includes(query) || p.description.toLowerCase().includes(query))
  );
  if (sortSelect.value === "low") list.sort((a,b) => a.price-b.price);
  if (sortSelect.value === "high") list.sort((a,b) => b.price-a.price);
  if (sortSelect.value === "name") list.sort((a,b) => a.name.localeCompare(b.name, "id"));
  return list;
}
function renderProducts() {
  const list = filteredProducts();
  document.getElementById("productTotal").textContent = `${list.length} produk`;
  document.getElementById("emptyState").classList.toggle("hidden", list.length > 0);
  grid.innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-visual">
        ${p.tag ? `<span class="product-tag">${escapeHtml(p.tag)}</span>` : ""}
        <span class="product-emoji">${p.emoji}</span>
      </div>
      <div class="product-info">
        <h3>${escapeHtml(p.name)}</h3>
        <p>${escapeHtml(p.description)}</p>
        <div class="product-bottom"><span class="price">${rupiah(p.price)}</span>
          <button class="add-button" data-add="${p.id}" aria-label="Tambah ${escapeHtml(p.name)}">+</button>
        </div>
      </div>
    </article>`).join("");
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}
function cartEntries() {
  return Object.entries(cart).map(([id, qty]) => {
    const product = products.find(p => p.id === Number(id));
    return product && qty > 0 ? { ...product, qty } : null;
  }).filter(Boolean);
}
function renderCart() {
  const entries = cartEntries();
  const count = entries.reduce((sum, p) => sum + p.qty, 0);
  const total = entries.reduce((sum, p) => sum + p.price*p.qty, 0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartTotal").textContent = rupiah(total);
  const holder = document.getElementById("cartItems");
  if (!entries.length) {
    holder.innerHTML = '<div class="cart-empty"><div style="font-size:38px">🛒</div><h3>Keranjang masih kosong</h3><p>Tambahkan produk yang kamu inginkan.</p></div>';
  } else {
    holder.innerHTML = entries.map(p => `
      <div class="cart-row">
        <div class="cart-emoji">${p.emoji}</div>
        <div><div class="cart-product-name">${escapeHtml(p.name)}</div>
          <div class="cart-product-price">${rupiah(p.price)} / item</div>
          <div class="qty-control"><button data-qty="${p.id}" data-change="-1" aria-label="Kurangi">−</button><span>${p.qty}</span><button data-qty="${p.id}" data-change="1" aria-label="Tambah">+</button></div>
          <button class="remove-button" data-remove="${p.id}">Hapus</button>
        </div><strong style="font-size:12px">${rupiah(p.price*p.qty)}</strong>
      </div>`).join("");
  }
  saveCart();
}
function openCart() {
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
  overlay.classList.remove("hidden");
}
function closeCart() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  overlay.classList.add("hidden");
}
grid.addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (!button) return;
  const id = Number(button.dataset.add);
  cart[id] = (cart[id] || 0) + 1;
  renderCart();
  showToast("Produk ditambahkan ke keranjang");
});
document.getElementById("cartItems").addEventListener("click", event => {
  const qtyButton = event.target.closest("[data-qty]");
  const removeButton = event.target.closest("[data-remove]");
  if (qtyButton) {
    const id = Number(qtyButton.dataset.qty);
    cart[id] = (cart[id] || 0) + Number(qtyButton.dataset.change);
    if (cart[id] <= 0) delete cart[id];
    renderCart();
  }
  if (removeButton) {
    delete cart[Number(removeButton.dataset.remove)];
    renderCart();
    showToast("Produk dihapus");
  }
});
document.getElementById("openCart").addEventListener("click", openCart);
document.getElementById("closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
searchInput.addEventListener("input", renderProducts);
sortSelect.addEventListener("change", renderProducts);
document.getElementById("categories").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  selectedCategory = button.dataset.category;
  document.querySelectorAll(".category").forEach(el => el.classList.toggle("active", el === button));
  renderProducts();
});
function openWhatsApp(message) {
  const number = ADMIN_WHATSAPP.replace(/\D/g, "");
  if (!number || number === "6281234567890") {
    showToast("Atur nomor admin di file script.js dulu");
    return;
  }
  window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}
document.getElementById("checkoutButton").addEventListener("click", () => {
  const entries = cartEntries();
  if (!entries.length) { showToast("Keranjang masih kosong"); return; }
  const name = document.getElementById("customerName").value.trim();
  if (!name) { document.getElementById("customerName").focus(); showToast("Isi nama pemesan dulu"); return; }
  const total = entries.reduce((sum, p) => sum + p.price*p.qty, 0);
  const lines = entries.map((p, i) => `${i+1}. ${p.name} x${p.qty} = ${rupiah(p.price*p.qty)}`);
  const message = `Halo admin Kimz Shop, saya ingin memesan:\n\nNama: ${name}\n${lines.join("\n")}\n\nTotal: ${rupiah(total)}\n\nMohon konfirmasi stok dan cara pembayarannya. Terima kasih.`;
  openWhatsApp(message);
});
document.getElementById("contactAdmin").addEventListener("click", () => {
  openWhatsApp("Halo admin Kimz Shop, saya ingin bertanya tentang produk.");
});
document.getElementById("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("light");
  const light = document.body.classList.contains("light");
  document.getElementById("themeToggle").textContent = light ? "☀" : "☾";
  try { localStorage.setItem("kimzShopTheme", light ? "light" : "dark"); } catch {}
});
try {
  if (localStorage.getItem("kimzShopTheme") === "light") {
    document.body.classList.add("light");
    document.getElementById("themeToggle").textContent = "☀";
  }
} catch {}
document.getElementById("year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
