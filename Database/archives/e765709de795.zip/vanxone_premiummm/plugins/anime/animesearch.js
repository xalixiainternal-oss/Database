// anime/animesearch — cari anime di AlqAnime lalu pilih nomor → pilih kualitas → link download (MediaFire diutamakan)
const axios = require('axios')

const API = 'https://www.sankavollerei.web.id/anime/alqanime'
const HEAD = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
const pending = new Map() // chat:sender -> { at, items }
const TTL = 30 * 60 * 1000

const api = (p, params) => axios.get(`${API}${p}`, { params, headers: HEAD, timeout: 30000, validateStatus: (s) => s < 500 }).then((r) => r.data)

// bentuk respons search bisa beda-beda; ambil array pertama yang isinya punya judul + slug/url
function pickList(d) {
  const seen = new Set()
  const walk = (v, depth = 0) => {
    if (!v || depth > 4 || seen.has(v)) return null
    if (typeof v === 'object') seen.add(v)
    if (Array.isArray(v)) {
      if (v.length && v.every((x) => x && typeof x === 'object') && v.some((x) => x.title && (x.slug || x.url))) return v
      for (const x of v) { const r = walk(x, depth + 1); if (r) return r }
      return null
    }
    if (typeof v === 'object') for (const k of Object.keys(v)) { const r = walk(v[k], depth + 1); if (r) return r }
    return null
  }
  return walk(d) || []
}
const slugOf = (it) => it.slug || String(it.url || '').replace(/\/+$/, '').split('/').pop()

async function search(q) {
  for (const [p, params] of [[`/search/${encodeURIComponent(q)}`], ['/search', { q }], ['/search', { query: q }]]) {
    try {
      const list = pickList(await api(p, params))
      if (list.length) return list.map((x) => ({ title: x.title, slug: slugOf(x), poster: x.poster, episode: x.episode || x.status })).filter((x) => x.slug)
    } catch {}
  }
  // cadangan: cari di daftar terbaru
  const home = pickList(await api('/home'))
  const k = q.toLowerCase()
  return home.filter((x) => String(x.title).toLowerCase().includes(k)).map((x) => ({ title: x.title, slug: slugOf(x), poster: x.poster, episode: x.episode }))
}

async function detail(slug) {
  const r = await api(`/detail/${encodeURIComponent(slug)}`)
  if (r?.status !== 'success' || !r.data) throw new Error('Detail anime tidak ditemukan')
  return r.data
}

const isMf = (u) => /mediafire\.com/i.test(u.url || '') || /mediafire/i.test(u.server || '')
const key = (m) => `${m.key.remoteJid}:${m.key.participant || m.key.remoteJid}`

module.exports = {
  name: 'alqsearch',
  command: ['alqsearch', 'alqcari', 'alqdl', 'alqunduh'],
  category: 'anime',
  emoji: '🎌',
  desc: 'Cari anime (AlqAnime) lalu download dengan pilihan kualitas',
  usage: '.alqsearch <judul>  →  .alqdl <nomor> [kualitas] [episode]',
  run: async ({ sock, msg, from, text, args, prefix, command, react, reply }) => {
    const isDl = ['alqdl', 'alqunduh'].includes(command)
    try {
      if (!isDl) {
        const q = String(text || '').trim()
        if (!q) return reply(`Masukkan judul anime.\nContoh: ${prefix}${command} naruto`)
        react?.('⏳')
        const items = (await search(q)).slice(0, 10)
        if (!items.length) { react?.('❌'); return reply(`❌ Anime "${q}" tidak ditemukan.`) }
        pending.set(key(msg), { at: Date.now(), items })
        react?.('✅')
        return reply(`🎌 *HASIL PENCARIAN: ${q}*\n\n${items.map((x, i) => `${i + 1}. ${x.title}${x.episode ? ` — ${x.episode}` : ''}`).join('\n')}\n\nPilih: *${prefix}alqdl <nomor>*\nContoh: ${prefix}alqdl 1`)
      }

      const st = pending.get(key(msg))
      if (!st || Date.now() - st.at > TTL) return reply(`Cari anime dulu: ${prefix}alqsearch <judul>`)
      const n = parseInt(args[0], 10)
      const item = st.items[n - 1]
      if (!item) return reply(`Nomor tidak valid. Pilih 1 - ${st.items.length}.`)
      react?.('⏳')
      const d = await detail(item.slug)
      const eps = Array.isArray(d.downloads) ? d.downloads : []
      const want = String(args[1] || '').toLowerCase().replace(/\s/g, '')
      const epFilter = String(args.slice(2).join(' ') || '').toLowerCase()

      if (!want) {
        const info = d.info || {}
        const res = [...new Set(eps.flatMap((e) => (e.links || []).map((l) => l.resolution).filter(Boolean)))]
        const cap = [`🎌 *${d.title || item.title}*`, `Status: ${info.status || '-'}  •  Tipe: ${info.tipe || '-'}`, `Episode/paket: ${eps.length}`, '', res.length ? `*Pilih kualitas:*\n${res.map((r) => `• ${prefix}alqdl ${n} ${String(r).replace(/\s/g, '')}`).join('\n')}` : 'Link download belum tersedia.', '', `Filter episode: ${prefix}alqdl ${n} <kualitas> <kata judul episode>`].join('\n')
        if (d.poster || item.poster) await sock.sendMessage(from, { image: { url: d.poster || item.poster }, caption: cap }, { quoted: msg }).catch(() => reply(cap))
        else await reply(cap)
        return react?.('✅')
      }

      const out = []
      for (const e of eps) {
        if (epFilter && !String(e.title || '').toLowerCase().includes(epFilter)) continue
        const l = (e.links || []).find((x) => String(x.resolution || '').toLowerCase().replace(/\s/g, '') === want)
        if (!l?.urls?.length) continue
        const urls = [...l.urls].filter((u) => u.url).sort((a, b) => Number(isMf(b)) - Number(isMf(a)))
        out.push(`*${e.title || 'Download'}*\n${urls.map((u) => `${isMf(u) ? '⭐ ' : '• '}${u.server || 'Server'}: ${u.url}`).join('\n')}`)
      }
      if (!out.length) { react?.('❌'); return reply(`❌ Kualitas *${args[1]}* tidak tersedia${epFilter ? ' untuk episode itu' : ''}. Ketik ${prefix}alqdl ${n} untuk melihat pilihan.`) }
      const body = out.join('\n\n')
      react?.('✅')
      return reply(`🎌 *${d.title || item.title}* — ${args[1]}\n(⭐ = MediaFire)\n\n${body.length > 3800 ? `${body.slice(0, 3800)}\n\n… dipotong, pakai filter episode: ${prefix}alqdl ${n} ${args[1]} <kata judul>` : body}`)
    } catch (e) {
      react?.('❌')
      reply(`❌ Gagal: ${e?.message || e}`)
    }
  }
}
