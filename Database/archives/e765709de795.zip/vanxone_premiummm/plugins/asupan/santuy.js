// asupan/santuy — satu file: metadata + kode fitur (gabungan dari engine7/plugins/asupan/santuy.js)
const __vx = require("../../lib/adapter/e7.js")
const __meta = {
  "name": "santuy",
  "command": [
    "santuy",
    "santuyvid"
  ],
  "category": "asupan",
  "desc": "Video santuy",
  "usage": ".santuy",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "cooldown": 10,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __vx.plugin("asupan/santuy", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/santuy.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const axios = __vxDef(require("axios"));
  const fs = __vxDef(require("fs"));
  const path = __vxDef(require("path"));
  const pluginConfig = {
      name: 'santuy',
      alias: ['santuyvid'],
      category: 'asupan',
      description: 'Video santuy',
      usage: '.santuy',
      example: '.santuy',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 10,
      energi: 1,
      isEnabled: true
  }
  
  function loadJsonData(filename) {
      try {
          const filePath = path.join(process.cwd(), 'src', 'tiktok', filename)
          if (fs.existsSync(filePath)) {
              return JSON.parse(fs.readFileSync(filePath, 'utf-8'))
          }
      } catch {}
      return []
  }
  
  async function handler(m, { sock }) {
      m.react('⏳')
      
      try {
          const data = loadJsonData('santuy.json')
          
          if (data.length === 0) {
              m.react('❌')
              return m.reply(`❌ Data tidak tersedia`)
          }
          
          const item = data[Math.floor(Math.random() * data.length)]
          
          const res = await axios.get(item.url, { 
              responseType: 'arraybuffer',
              timeout: 60000
          })
          
          m.react('✅')
          
          await sock.sendMessage(m.chat, {
              video: Buffer.from(res.data),
              caption: `😎 *sᴀɴᴛᴜʏ*`
          }, { quoted: m })
          
      } catch (error) {
          m.react('❌')
          m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> Video tidak ditemukan`)
      }
  }
  
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
