// fitur tambahan × - vanXone </> (cek/cekpelit)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpelit", {"command":["cekpelit"],"category":"cek","desc":"Fitur cekpelit [@user]","usage":".cekpelit"})
