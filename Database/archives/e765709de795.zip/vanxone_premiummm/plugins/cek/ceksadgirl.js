// fitur tambahan × - vanXone </> (cek/ceksadgirl)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceksadgirl", {"command":["ceksadgirl"],"category":"cek","desc":"Fitur ceksadgirl [@tag/nama]","usage":".ceksadgirl"})
