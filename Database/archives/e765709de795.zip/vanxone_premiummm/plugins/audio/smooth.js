// fitur tambahan × - vanXone </> (audio/smooth)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/smooth", {"command":["smooth"],"category":"audio","desc":"Fitur smooth","usage":".smooth"})
