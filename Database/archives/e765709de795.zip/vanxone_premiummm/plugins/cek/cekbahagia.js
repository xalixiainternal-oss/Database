// fitur tambahan × - vanXone </> (cek/cekbahagia)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbahagia", {"command":["cekbahagia"],"category":"cek","desc":"Fitur cekbahagia [@user]","usage":".cekbahagia"})
