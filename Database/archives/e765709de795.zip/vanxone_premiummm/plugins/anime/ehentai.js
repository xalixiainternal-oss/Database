// fitur tambahan × - vanXone </> (anime/ehentai)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/ehentai", {"command":["ehentai"],"category":"anime","desc":"Fitur <query | url> [-n jumlah]","usage":".ehentai"})
