// fitur tambahan × - vanXone </> (audio/reverse)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/reverse", {"command":["reverse"],"category":"audio","desc":"Fitur reverse","usage":".reverse"})
