// ai/beautyplus — fitur tambahan (plugins.zip), disesuaikan untuk × - vanXone </>
const __vx = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "beautyplus",
    "filterbeauty"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur beautyplus",
  "usage": ".beautyplus"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __vx.plugin("vxnew/ai/beautyplus", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/beautyplus.js"
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __vxExports = {};
  let handler = async (m, { conn, usedPrefix, command }) => {
    try {
      const q = m.quoted ? m.quoted : m;
      const mime = q?.msg?.mimetype || q?.mimetype || "";
      if (!/image/.test(mime)) {
        return m.reply(`⚠️ Reply gambar dengan caption ${usedPrefix + command}`);
      }
      
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
      const media = await q.download();
      const formData = new FormData();
      formData.append("file", new Blob([media], { type: "image/jpeg" }), "image.jpg");
      
      const response = await fetch(`${global.web}/api/ai/beautyplus?apikey=${global.apikey?.vxapi}`, {
        method: 'POST',
        body: formData
      });
      const json = await response.json();
      
      let resultUrl = json.data?.image_url || json.data?.url || json.result?.image_url || json.result?.url || json.image_url || json.result || json.data;
      if (typeof resultUrl === 'object' && resultUrl !== null) {
        resultUrl = resultUrl.url || resultUrl.image_url || JSON.stringify(resultUrl);
      }
      
      if (json.status && typeof resultUrl === 'string' && resultUrl.startsWith('http')) {
        await conn.sendMessage(m.chat, {
          image: { url: resultUrl },
          caption: `✅ *BeautyPlus Filter Success!*`
        }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + resultUrl));
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      } else {
        throw new Error(json.error || json.detail || json.message || "Gagal mempercantik gambar");
      }
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || "Terjadi kesalahan internal"));
    }
  };
  
  handler.help = ["beautyplus"];
  handler.premium = true;
  handler.command = ["beautyplus", "filterbeauty"];
  handler.tags = ["ai"];
  handler.limit = 1;
  
  
  
  const __vxDefault = handler

  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  for (const k of ['before', 'all']) { if (typeof __vxExports[k] === 'function' && typeof __vxDefault === 'function' && !__vxDefault[k]) __vxDefault[k] = __vxExports[k] }
  return __vxExports
})
