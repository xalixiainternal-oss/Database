// asupan/panrika — satu file: metadata + kode fitur (gabungan dari engine5/plugins/asupan/panrika.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "panrika",
  "command": [
    "panrika"
  ],
  "category": "asupan",
  "desc": "Fitur panrika",
  "usage": ".panrika",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __vx.plugin("asupan/panrika", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/panrika.js'
  const __vxExports = {};
  const handler = async (m, { sock, reply }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  
  	try {
  		const baseUrl = global.APIs?.kyzz;
  		const apiKey = global.APIKeys?.[baseUrl] || global.APIKeys?.kyzz;
  		const fallbackUrl = `${baseUrl}/api/asupan/panrika?apikey=${apiKey}`;
  
  		const data = await global.fetchApi('kyzz', '/api/asupan/panrika').catch(() => null);
  
  		let mediaUrl = fallbackUrl;
  		if (data) {
  			if (typeof data === 'string' && data.startsWith('http')) {
  				mediaUrl = data;
  			} else if (data.url) {
  				mediaUrl = data.url;
  			} else if (data.result) {
  				mediaUrl = typeof data.result === 'string' ? data.result : (data.result.url || data.result.link);
  			}
  		}
  
  		try {
  			await sock.sendMessage(m.chat, {
  				video: { url: mediaUrl },
  				caption: `🎥 *Asupan Panrika*\n\n© ${global.namaBot}`,
  				mimetype: 'video/mp4'
  			}, { quoted: m });
  		} catch {
  			await sock.sendMessage(m.chat, {
  				image: { url: mediaUrl },
  				caption: `📸 *Asupan Panrika*\n\n© ${global.namaBot}`
  			}, { quoted: m });
  		}
  
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } });
  
  	} catch (e) {
  		console.error('[ASUPAN PANRIKA ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		return reply('❌ Gagal mengambil asupan Panrika.');
  	}
  };
  
  handler.help = ['panrika'];
  handler.tags = ['asupan'];
  handler.command = ['panrika'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
