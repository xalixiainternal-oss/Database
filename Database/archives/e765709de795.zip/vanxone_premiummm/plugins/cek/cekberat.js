// fitur tambahan × - vanXone </> (cek/cekberat)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekberat", {"command":["cekberat","berat","weight"],"category":"cek","desc":"Cek berat badan random","usage":".cekberat"})
