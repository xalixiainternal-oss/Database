// fitur tambahan × - vanXone </> (cek/cekbego)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbego", {"command":["cekbego"],"category":"cek","desc":"Fitur cekbego [@tag/nama]","usage":".cekbego"})
