// fitur tambahan × - vanXone </> (cek/cekngantuk)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekngantuk", {"command":["cekngantuk","ngantuk","sleepy"],"category":"cek","desc":"Cek tingkat ngantuk kamu","usage":".cekngantuk"})
