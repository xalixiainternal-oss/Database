// fitur tambahan × - vanXone </> (cek/cekdermawan)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekdermawan", {"command":["cekdermawan"],"category":"cek","desc":"Fitur cekdermawan [@user]","usage":".cekdermawan"})
