// fitur tambahan × - vanXone </> (pushkontak/stoppush)
module.exports = require('../../lib/adapter/e9.js').plugin("pushkontak/stoppush", {"command":["stoppushkontak","stoppus"],"category":"broadcast","desc":"Fitur stoppushkontak","usage":".stoppushkontak","owner":true})
