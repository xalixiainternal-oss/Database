// fitur tambahan × - vanXone </> (cek/cekpemberani)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpemberani", {"command":["cekpemberani"],"category":"cek","desc":"Fitur cekpemberani [@user]","usage":".cekpemberani"})
