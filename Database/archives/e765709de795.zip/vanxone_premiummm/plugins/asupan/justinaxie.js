// cecan/justinaxie — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/justinaxie.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "justinaxie",
  "command": [
    "justinaxie"
  ],
  "category": "asupan",
  "desc": "Perintah justinaxie",
  "usage": "",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __vx.plugin("cecan/justinaxie", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/justinaxie.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const sendCecan = __vxDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		await sendCecan(sock, m, reply, 'Justinaxie');
  	} catch (e) {
  		console.error('[CECAN JUSTINAXIE ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cecan Justinaxie.');
  	}
  };
  
  handler.command = ['justinaxie'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
