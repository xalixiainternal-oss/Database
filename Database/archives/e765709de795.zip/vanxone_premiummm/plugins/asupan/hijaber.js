// cecan/hijaber — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/hijaber.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "hijaber",
  "command": [
    "hijaber"
  ],
  "category": "asupan",
  "desc": "Perintah hijaber",
  "usage": "",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __vx.plugin("cecan/hijaber", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/hijaber.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const sendCecan = __vxDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	try {
  		await sendCecan(sock, m, reply, 'Hijaber');
  	} catch (e) {
  		console.error('[CECAN HIJABER ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		reply('❌ Gagal mengambil gambar cecan Hijaber.');
  	}
  };
  
  handler.command = ['hijaber'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
