// fitur tambahan × - vanXone </> (cek/cekkhodam)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkhodam", {"command":["cekkhodam"],"category":"cek","desc":"Fitur cekkhodam [@tag/nama]","usage":".cekkhodam"})
