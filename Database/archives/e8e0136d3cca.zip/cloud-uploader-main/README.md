# SILENTPHANTOM — File Uploader

> Anonymous file relay. Drop. Get link. Done.

SILENTPHANTOM adalah file uploader tanpa autentikasi yang berjalan di **Cloudflare Workers**. File yang diunggah disimpan langsung ke repositori GitHub (sebagai storage) dan disajikan kembali melalui domain sendiri dengan cache edge permanen.

---

## Fitur

| Fitur | Deskripsi |
|-------|-----------|
| **Anonymous** | Tidak perlu login, tidak ada tracking |
| **Drag & Drop** | Upload langsung dari browser dengan progress bar |
| **URL Relay** | Unggah file dari URL eksternal tanpa mendownload ke lokal |
| **Auto Kategori** | File otomatis tersimpan dalam folder sesuai jenisnya (gambar, video, audio, dokumen, arsip, lainnya) |
| **Magic Byte Detection** | MIME type dideteksi dari header file biner, bukan hanya dari ekstensi |
| **Edge Cache** | File di-serve dengan `Cache-Control: immutable` selama 1 tahun |
| **Max 95MB** | Batas praktis dari GitHub Contents API |

---

## Arsitektur

```
┌─────────────────┐      POST /api/upload       ┌─────────────────┐
│   User Browser  │ ───────────────────────────> │ Cloudflare      │
│  (drag & drop)  │                              │ Worker (edge)   │
└─────────────────┘                              └────────┬────────┘
                                                          │ base64 PUT
                                                          ▼
                                                   ┌─────────────────┐
                                                   │  GitHub Repo    │
                                                   │  Database/      │
                                                   │  ├── images/    │
                                                   │  ├── videos/    │
                                                   │  ├── audios/    │
                                                   │  ├── documents/ │
                                                   │  ├── archives/  │
                                                   │  └── others/    │
                                                   └─────────────────┘
                                                          │
                              GET /f/:category/:filename  │ raw.githubusercontent.com
                              ───────────────────────────── ▼
                                                   ┌─────────────────┐
                                                   │  User (serve)   │
                                                   └─────────────────┘
```

---

## Endpoint API

### 1. Upload File (Multipart)

```bash
curl -X POST https://silentphantom-uploader.workers.dev/api/upload \
  -F "file=@photo.jpg"
```

### 2. Upload dari URL (JSON)

```bash
curl -X POST https://silentphantom-uploader.workers.dev/api/upload \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com/image.jpg"}'
```

### 3. Response (200 OK)

```json
{
  "status": true,
  "message": "Upload successful",
  "result": {
    "filename": "34a0e8f7bdc6.jpg",
    "category": "images",
    "path": "images/34a0e8f7bdc6.jpg",
    "url": "https://silentphantom-uploader.workers.dev/f/images/34a0e8f7bdc6.jpg",
    "mimetype": "image/jpeg",
    "size": 301441
  }
}
```

### 4. Serve File

```
GET /f/:category/:filename
```

Contoh: `https://silentphantom-uploader.workers.dev/f/images/34a0e8f7bdc6.jpg`

---

## Struktur Folder GitHub

File tersimpan otomatis dalam subfolder berdasarkan tipe MIME:

```
Database/
├── images/       ← jpg, png, gif, webp, svg, bmp
├── videos/       ← mp4, webm, mov
├── audios/       ← mp3, ogg, wav, weba
├── documents/    ← pdf, docx, xlsx, pptx, txt, html, css
├── archives/     ← zip, rar, tar, 7z, gzip
└── others/       ← sisanya (bin, json, xml, js, dll)
```

---

## Tech Stack

| Layer | Teknologi |
|-------|-----------|
| Framework | [TanStack Start](https://tanstack.com/start) (React 19 + Vite 7) |
| Styling | Tailwind CSS v4 + shadcn/ui |
| Runtime | Cloudflare Workers (`nodejs_compat`) |
| Storage | GitHub Contents API (repositori pribadi) |
| Deploy | Wrangler CLI |

---

## Setup & Deploy

### 1. Clone & Install

```bash
git clone <repo-url>
cd silentphantom-uploader
bun install
```

### 2. Build

```bash
bun run build
```

Output ada di `.output/`:
- `.output/server/index.mjs` — Worker entry
- `.output/public/` — static assets

### 3. Set Secrets

Wajib ada 4 environment variable / secret di Cloudflare:

```bash
wrangler secret put GITHUB_TOKEN
wrangler secret put GITHUB_OWNER
wrangler secret put GITHUB_REPO
wrangler secret put GITHUB_BRANCH
```

| Secret | Nilai |
|--------|-------|
| `GITHUB_TOKEN` | Personal Access Token GitHub (scope: `repo`) — buat di [github.com/settings/tokens](https://github.com/settings/tokens) |
| `GITHUB_OWNER` | Username atau org pemilik repo, contoh: `kayllano` |
| `GITHUB_REPO` | Nama repo storage, contoh: `Kayllano-Backend` |
| `GITHUB_BRANCH` | Branch target, biasanya `main` |

> Atau isi manual lewat Cloudflare Dashboard → Workers & Pages → Variables and Secrets → **+ Add** → Type: **Secret**.

### 4. Deploy

```bash
wrangler deploy
```

URL Worker akan muncul, contoh:  
`https://silentphantom-uploader.<subdomain>.workers.dev`

---

## Update Kode

Setiap kali ada perubahan:

```bash
bun run build && wrangler deploy
```

---

## Limit

| Batasan | Nilai |
|---------|-------|
| Max file size | ~95 MB (batas GitHub Contents API) |
| CPU per request | 30 detik (Workers Free) |
| Filename | Random hex, original name tidak disimpan |
| Retention | Permanen (selama file ada di repo GitHub) |

---

## Deteksi Tipe File (Magic Bytes)

Uploader tidak hanya mengandalkan header `Content-Type`, tapi juga mendeteksi tipe file dari signature biner awal file:

| Signature | Tipe |
|-----------|------|
| `FF D8 FF` | JPEG |
| `89 50 4E 47` | PNG |
| `47 49 46` | GIF |
| `52 49 46 46 ... 57 45 42 50` | WebP |
| `25 50 44 46` | PDF |
| `50 4B 03/05` | ZIP (termasuk DOCX/XLSX) |
| `66 74 79 70` | MP4 |
| `ID3` atau `FF FB` | MP3 |

---

## Kontribusi & Kontak

Dibuat oleh **kayXD** — Ichika Multidevice ops

- Telegram: [@kayzuMD](https://t.me/kayzuMD)
- Instagram: [@kayxydl](https://www.instagram.com/kayxydl)
- WhatsApp Channel: [Join](https://whatsapp.com/channel/0029VbA0PhgJP20zFljfUS0b)

Supported by [ZELAPIS](https://zelapioffciall.dpdns.org)

---

## License

Private / Personal use. Semua byte lewat tanpa jejak.
