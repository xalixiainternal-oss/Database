// fitur tambahan × - vanXone </> (cek/cekgacha)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgacha", {"command":["cekgacha","luck"],"category":"cek","desc":"Cek hoki gacha kamu","usage":".cekgacha"})
