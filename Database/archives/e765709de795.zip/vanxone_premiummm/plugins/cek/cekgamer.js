// fitur tambahan × - vanXone </> (cek/cekgamer)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgamer", {"command":["cekgamer","gamer","pro"],"category":"cek","desc":"Cek seberapa pro gamer kamu","usage":".cekgamer"})
