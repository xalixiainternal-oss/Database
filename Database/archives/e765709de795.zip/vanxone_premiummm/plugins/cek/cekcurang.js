// fitur tambahan × - vanXone </> (cek/cekcurang)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcurang", {"command":["cekcurang"],"category":"cek","desc":"Fitur cekcurang [@user]","usage":".cekcurang"})
