// fitur tambahan × - vanXone </> (ai/termai-audio)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-audio", {"command":["songai","songgenerator","voicecover","termaicover"],"category":"ai","desc":"Fitur songai <prompt>","usage":".songai","premium":true})
