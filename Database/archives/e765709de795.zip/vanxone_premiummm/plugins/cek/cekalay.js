// fitur tambahan × - vanXone </> (cek/cekalay)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekalay", {"command":["cekalay"],"category":"cek","desc":"Fitur cekalay [@user]","usage":".cekalay"})
