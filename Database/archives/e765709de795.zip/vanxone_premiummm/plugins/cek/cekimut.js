// cek/cekimut — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekimut.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekimut",
  "command": [
    "imut",
    "cute"
  ],
  "category": "cek",
  "desc": "Cek seberapa imut kamu",
  "usage": ".cekimut <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekimut", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekimut.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekimut',
      alias: ['imut', 'cute'],
      category: 'cek',
      description: 'Cek seberapa imut kamu',
      usage: '.cekimut <nama>',
      example: '.cekimut Ani',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'IMUT BANGET! Kawaii~~ 🥺💕'
      } else if (percent >= 70) {
          desc = 'Imutnya kebangetan! 😍'
      } else if (percent >= 50) {
          desc = 'Lumayan imut~ 🌸'
      } else if (percent >= 30) {
          desc = 'Ada imutnya dikit 😊'
      } else {
          desc = 'Mungkin cool bukan imut? 😎'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat keimutan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat keimutan @${mentioned.split('@')[0]} yak? 
      
  Tingkat keimutan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
