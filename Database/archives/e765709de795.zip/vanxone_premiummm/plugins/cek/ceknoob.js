// fitur tambahan × - vanXone </> (cek/ceknoob)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceknoob", {"command":["ceknoob"],"category":"cek","desc":"Fitur ceknoob [@user]","usage":".ceknoob"})
