// fitur tambahan × - vanXone </> (cek/cekotaku)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekotaku", {"command":["cekotaku","otaku"],"category":"cek","desc":"Cek tingkat otaku kamu","usage":".cekotaku"})
