// fitur tambahan × - vanXone </> (cek/ceknakal)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceknakal", {"command":["ceknakal"],"category":"cek","desc":"Fitur ceknakal [@user]","usage":".ceknakal"})
