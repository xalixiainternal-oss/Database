# Deploy ke Cloudflare Workers

Project ini sekarang dikonfigurasi untuk **Cloudflare Workers** (bukan Vercel).
Cloudflare nggak punya hard cap body request, jadi file gede (s/d ~95MB sesuai
limit GitHub Contents API) bisa di-upload.

## Cara deploy

### 1. Install Wrangler (sekali aja)

```bash
npm install -g wrangler
wrangler login
```

### 2. Build project

```bash
bun install
bun run build
```

Ini menghasilkan `.output/` yang berisi:
- `.output/server/index.mjs` — Worker entry (SSR + API routes)
- `.output/public/` — static assets (client bundle, gambar, dll)

### 3. Set secrets

Wajib set 4 secrets ini (sekali aja, lalu tersimpan di Cloudflare):

```bash
wrangler secret put GITHUB_TOKEN
wrangler secret put GITHUB_OWNER
wrangler secret put GITHUB_REPO
wrangler secret put GITHUB_BRANCH
```

Setiap perintah akan minta input value-nya (paste, enter).

- `GITHUB_TOKEN` — Personal Access Token (scope: `repo`) — buat di https://github.com/settings/tokens
- `GITHUB_OWNER` — username/org pemilik repo storage
- `GITHUB_REPO` — nama repo storage
- `GITHUB_BRANCH` — biasanya `main`

### 4. Deploy

```bash
wrangler deploy
```

URL Worker akan keluar (mis. `https://silentphantom-uploader.<your-subdomain>.workers.dev`).

### 5. Custom domain (opsional)

Di Cloudflare Dashboard → Workers & Pages → pilih worker `silentphantom-uploader`
→ Settings → Domains & Routes → Add Custom Domain. Masukkan domain kamu
(domain harus sudah ada di Cloudflare DNS account yang sama).

## Update kode

Setiap kali kamu ubah kode, jalanin lagi:

```bash
bun run build && wrangler deploy
```

Atau pakai GitHub Actions / Cloudflare Pages CI buat auto-deploy on push.

## Limit penting

- **Body request**: praktis nggak ada cap (Worker tanpa Smart Placement).
- **GitHub Contents API**: max ~100MB per file. Kode set `MAX_SIZE = 95MB`.
- **CPU per request**: 30 detik (Workers Free) / 5 menit (Paid). Upload 95MB
  ke GitHub via base64 PUT umumnya muat di Free tier.
- **Worker bundle size**: max 10MB (gzipped). Project ini jauh di bawah itu.
