// fitur tambahan × - vanXone </> (cek/cekpenakut)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpenakut", {"command":["cekpenakut"],"category":"cek","desc":"Fitur cekpenakut [@user]","usage":".cekpenakut"})
