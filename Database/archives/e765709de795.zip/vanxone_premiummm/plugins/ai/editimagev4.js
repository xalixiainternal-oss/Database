// ai/editimagev4 — fitur tambahan (plugins.zip), disesuaikan untuk × - vanXone </>
const __vx = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "editimagev4"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur editimagev4",
  "usage": ".editimagev4 <prompt>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __vx.plugin("vxnew/ai/editimagev4", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/editimagev4.js"
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __vxExports = {};
  let handler = async (m, { conn, usedPrefix, command, args }) => {
    try {
      const prompt = args.join(' ');
      if (!prompt) return m.reply(`⚠️ Masukkan prompt editan!\nContoh: ${usedPrefix + command} ubah jadi rambut merah`);
      
      const q = m.quoted ? m.quoted : m;
      const mime = q?.msg?.mimetype || q?.mimetype || "";
      if (!/image/.test(mime)) {
        return m.reply(`⚠️ Reply gambar dengan caption ${usedPrefix + command} <prompt>`);
      }
      
      await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
  
      const media = await q.download();
      const formData = new FormData();
      formData.append("file", new Blob([media], { type: "image/jpeg" }), "image.jpg");
      formData.append("prompt", prompt);
  
      const response = await fetch(`${global.web}/api/ai/editimagev4?apikey=${global.apikey?.vxapi}`, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        let errText = "Gagal memproses gambar";
        try {
          const errJson = await response.json();
          errText = errJson.error || errJson.message || errText;
        } catch (e) {}
        throw new Error(errText);
      }
      
      const contentType = response.headers.get('content-type') || "";
      if (contentType.includes('application/json')) {
        const json = await response.json();
        if (!json.status) throw new Error(json.error || "Terjadi kesalahan di server");
        const url = json.data || json.result;
        if (!url) throw new Error("No URL returned");
        await conn.sendMessage(m.chat, {
          image: { url },
          caption: `✅ *Edit Image V4 Success!*\n\n📝 *Prompt:* ${prompt}`
        }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + url));
      } else {
        const buffer = Buffer.from(await response.arrayBuffer());
        await conn.sendMessage(m.chat, {
          image: buffer,
          caption: `✅ *Edit Image V4 Success!*\n\n📝 *Prompt:* ${prompt}`
        }, { quoted: m });
      }
      
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
      console.error(e);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      m.reply("❌ Error: " + (e.message || "Terjadi kesalahan internal"));
    }
  };
  
  handler.premium = true;
  handler.help = ["editimagev4 <prompt>"];
  handler.command = ["editimagev4"];
  handler.tags = ["ai"];
  handler.limit = 2;
  
  
  
  const __vxDefault = handler

  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  for (const k of ['before', 'all']) { if (typeof __vxExports[k] === 'function' && typeof __vxDefault === 'function' && !__vxDefault[k]) __vxDefault[k] = __vxExports[k] }
  return __vxExports
})
