// fitur tambahan × - vanXone </> (cek/cekgabut)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgabut", {"command":["cekgabut"],"category":"cek","desc":"Fitur cekgabut [@user]","usage":".cekgabut"})
