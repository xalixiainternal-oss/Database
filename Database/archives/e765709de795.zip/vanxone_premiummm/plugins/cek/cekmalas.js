// cek/cekmalas — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekmalas.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekmalas",
  "command": [
    "cekmalas",
    "malas",
    "lazy"
  ],
  "category": "cek",
  "desc": "Cek seberapa malas kamu",
  "usage": ".cekmalas <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekmalas", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekmalas.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekmalas',
      alias: ['malas', 'lazy'],
      category: 'cek',
      description: 'Cek seberapa malas kamu',
      usage: '.cekmalas <nama>',
      example: '.cekmalas Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) {
          desc = 'SUPER MALAS! Raja rebahan! 🛏️'
      } else if (percent >= 70) {
          desc = 'Malas banget! 😴'
      } else if (percent >= 50) {
          desc = 'Lumayan malas 🥱'
      } else if (percent >= 30) {
          desc = 'Sedikit malas 😊'
      } else {
          desc = 'Rajin banget! 💪'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kemalasan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kemalasan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kemalasan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
