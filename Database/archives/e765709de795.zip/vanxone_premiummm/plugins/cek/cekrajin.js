// fitur tambahan × - vanXone </> (cek/cekrajin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekrajin", {"command":["cekrajin"],"category":"cek","desc":"Fitur cekrajin [@user]","usage":".cekrajin"})
