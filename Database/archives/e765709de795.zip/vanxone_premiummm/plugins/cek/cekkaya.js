// cek/cekkaya — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekkaya.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekkaya",
  "command": [
    "kaya",
    "rich"
  ],
  "category": "cek",
  "desc": "Cek seberapa kaya kamu",
  "usage": ".cekkaya <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekkaya", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekkaya.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekkaya',
      alias: ['kaya', 'rich'],
      category: 'cek',
      description: 'Cek seberapa kaya kamu',
      usage: '.cekkaya <nama>',
      example: '.cekkaya Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      let emoji = ''
      if (percent >= 90) {
          desc = 'Sultan! Crazy rich! 💎'
          emoji = '👑'
      } else if (percent >= 70) {
          desc = 'Tajir melintir! 💰'
          emoji = '💎'
      } else if (percent >= 50) {
          desc = 'Lumayan berada 💵'
          emoji = '💰'
      } else if (percent >= 30) {
          desc = 'Cukup lah buat hidup 😊'
          emoji = '💵'
      } else {
          desc = 'Semangat nabung! 🙏'
          emoji = '🪙'
      }
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kekayaan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kekayaan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kekayaan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
