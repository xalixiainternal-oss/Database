// fitur tambahan × - vanXone </> (cek/cekkepribadian)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkepribadian", {"command":["cekkepribadian","kepribadian","personality"],"category":"cek","desc":"Cek kepribadian kamu","usage":".cekkepribadian"})
