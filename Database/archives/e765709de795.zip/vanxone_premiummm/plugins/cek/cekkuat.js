// fitur tambahan × - vanXone </> (cek/cekkuat)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkuat", {"command":["cekkuat"],"category":"cek","desc":"Fitur cekkuat [@user]","usage":".cekkuat"})
