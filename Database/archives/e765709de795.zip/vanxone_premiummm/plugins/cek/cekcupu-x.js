// fitur tambahan × - vanXone </> (cek/cekcupu)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcupu", {"command":["cekcupu"],"category":"cek","desc":"Fitur cekcupu [@user]","usage":".cekcupu"})
