// ai/tocermin — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/tocermin.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "tocermin",
  "command": [
    "tocermin",
    "tomirror"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi efek cermin (mirror reflection)",
  "usage": ".tocermin (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __vx.plugin("ai/tocermin", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tocermin.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const te = __vxDef(require("../../lib/ext/src/lib/vanxone-error.js"));
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  
  const pluginConfig = {
      name: 'tocermin',
      alias: ['mirror', 'tomirror'],
      category: 'ai',
      description: 'Ubah foto menjadi efek cermin (mirror reflection)',
      usage: '.tocermin (reply/kirim gambar)',
      example: '.tocermin',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Create a mirror reflection effect of this image. 
  Add a realistic reflection as if the subject is in front of a mirror or reflective surface. 
  Ensure symmetry, smooth reflection blending, realistic lighting and shadows. 
  Keep the original identity and details, high quality, photorealistic.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🪞 *ᴛᴏ ᴄᴇʀᴍɪɴ*\n\n` +
              `> Kirim/reply gambar untuk efek cermin\n\n` +
              `\`${m.prefix}tocermin\``
          )
      }
      
      m.react('🕕')
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image',
          })
          
      } catch (error) { globalThis.__vanxoneCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
