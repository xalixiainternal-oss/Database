// fitur tambahan × - vanXone </> (cek/cekoverpower)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekoverpower", {"command":["cekoverpower","overpower","op"],"category":"cek","desc":"Cek tingkat overpower kamu","usage":".cekoverpower"})
