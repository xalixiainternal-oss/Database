// fitur tambahan × - vanXone </> (cek/cekjulid)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjulid", {"command":["cekjulid"],"category":"cek","desc":"Fitur cekjulid [@user]","usage":".cekjulid"})
