// ai/tooilpainting — satu file: metadata + kode fitur (gabungan dari engine3/plugins/ai/tooilpainting.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "tooilpainting",
  "command": [
    "tooilpainting",
    "oilpainting",
    "tooil",
    "oil"
  ],
  "category": "ai",
  "desc": "Ubah foto menjadi gaya lukisan minyak (oil painting)",
  "usage": ".tooilpainting (reply/kirim gambar)",
  "owner": false,
  "group": false,
  "private": false,
  "premium": true,
  "admin": false,
  "botAdmin": false,
  "cooldown": 60,
  "energi": 3,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/ai").split('\\').join('/')
module.exports = __vx.plugin("ai/tooilpainting", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/tooilpainting.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const { live3d } = require("../../lib/ext/src/scraper/seaart.e3.js");
  const te = __vxDef(require("../../lib/ext/src/lib/vanxone-error.js"));
  const pluginConfig = {
      name: 'tooilpainting',
      alias: ['oilpainting', 'tooil', 'oil'],
      category: 'ai',
      description: 'Ubah foto menjadi gaya lukisan minyak (oil painting)',
      usage: '.tooilpainting (reply/kirim gambar)',
      example: '.tooilpainting',
      isOwner: false,
      isPremium: true,
      isGroup: false,
      isPrivate: false,
      cooldown: 60,
      energi: 3,
      isEnabled: true
  }
  
  const PROMPT = `Transform this image into a classical oil painting style. 
  Apply thick brushstrokes, rich colors, and the texture of traditional oil paint on canvas. 
  Keep the original composition but make it look like a masterpiece painting 
  with visible brushwork, artistic color blending, and that timeless gallery-quality aesthetic.`
  
  async function handler(m, { sock }) {
      const isImage = m.isImage || (m.quoted && (m.quoted.isImage || m.quoted.type === 'imageMessage'))
      
      if (!isImage) {
          return m.reply(
              `🖼️ *ᴛᴏ ᴏɪʟ ᴘᴀɪɴᴛɪɴɢ*\n\n` +
              `> Kirim/reply gambar untuk diubah ke gaya lukisan minyak\n\n` +
              `\`${m.prefix}tooilpainting\``
          )
      }
      
      m.react('🕕')
      
      try {
          let buffer
          if (m.quoted && m.quoted.isMedia) {
              buffer = await m.quoted.download()
          } else if (m.isMedia) {
              buffer = await m.download()
          }
          
          if (!buffer) {
              m.react('❌')
              return m.reply(`❌ Gagal mendownload gambar`)
          }
          
          const result = await live3d(buffer, PROMPT)
          
          m.react('✅')
          
          await sock.sendMedia(m.chat, result.image, null, m, {
              type: 'image',
          })
          
      } catch (error) { globalThis.__vanxoneCatch?.(error);
          m.react('☢')
          m.reply(te(m.prefix, m.command, m.pushName))
      }
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
