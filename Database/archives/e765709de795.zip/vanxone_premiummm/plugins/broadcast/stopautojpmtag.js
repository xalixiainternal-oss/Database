// fitur tambahan × - vanXone </> (jpm/stopautojpmtag)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/stopautojpmtag", {"command":["stopautojpmtag"],"category":"broadcast","desc":"Fitur stopautojpmtag","usage":".stopautojpmtag","owner":true})
