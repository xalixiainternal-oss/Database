// fitur tambahan × - vanXone </> (cek/cekbijak)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbijak", {"command":["cekbijak"],"category":"cek","desc":"Fitur cekbijak [@user]","usage":".cekbijak"})
