// fitur tambahan × - vanXone </> (cek/ceksadis)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceksadis", {"command":["ceksadis"],"category":"cek","desc":"Fitur ceksadis [@user]","usage":".ceksadis"})
