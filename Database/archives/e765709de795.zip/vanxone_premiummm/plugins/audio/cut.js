// fitur tambahan × - vanXone </> (audio/cut)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/cut", {"command":["cut"],"category":"audio","desc":"Fitur cutaudio","usage":".cut"})
