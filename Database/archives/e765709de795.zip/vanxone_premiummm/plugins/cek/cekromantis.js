// fitur tambahan × - vanXone </> (cek/cekromantis)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekromantis", {"command":["cekromantis"],"category":"cek","desc":"Fitur cekromantis [@user]","usage":".cekromantis"})
