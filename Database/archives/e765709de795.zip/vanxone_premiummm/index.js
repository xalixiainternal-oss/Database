// Titik masuk bot × - vanXone </> (panel/VPS: jadikan index.js sebagai file utama). Isi bot ada di lib/core/bot.js
require('./lib/core/bot')
