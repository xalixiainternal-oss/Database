// fitur tambahan × - vanXone </> (anime/anilist)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/anilist", {"command":["anilist"],"category":"anime","desc":"Fitur anilist","usage":".anilist"})
