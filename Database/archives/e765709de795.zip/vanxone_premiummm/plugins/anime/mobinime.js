// fitur tambahan × - vanXone </> (anime/mobinime)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/mobinime", {"command":["mobinime"],"category":"anime","desc":"Fitur mobinime","usage":".mobinime"})
