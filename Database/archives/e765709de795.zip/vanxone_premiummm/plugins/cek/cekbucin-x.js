// fitur tambahan × - vanXone </> (cek/cekbucin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekbucin", {"command":["cekbucin"],"category":"cek","desc":"Fitur cekbucin [@tag/nama]","usage":".cekbucin"})
