import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/api/docs")({
  component: DocsPage,
  head: () => ({
    meta: [
      { title: "API Docs — SILENTPHANTOM" },
      { name: "description", content: "REST endpoint untuk upload file." },
    ],
  }),
});

function DocsPage() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-border bg-background/90 backdrop-blur sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-foreground text-background grid place-items-center font-mono font-bold text-sm">SP</div>
            <span className="font-mono text-sm font-bold">← back</span>
          </Link>
          <span className="tag-dark">api · v1</span>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-6 py-12 space-y-8">
        <div>
          <div className="label-mono mb-3">// reference</div>
          <h1 className="text-5xl font-bold tracking-tighter">API Documentation</h1>
          <p className="mt-3 text-muted-foreground text-sm max-w-xl">
            Stateless REST endpoint. Anonymous, no API key required.
          </p>
        </div>

        <Section method="POST" path="/api/upload" desc="Upload via multipart form atau JSON body { url }.">
          <Code title="multipart/form-data">
{`curl -X POST https://x.xcute.workers.dev/api/upload \\
  -F "file=@/path/to/image.jpg"`}
          </Code>
          <Code title="application/json">
{`curl -X POST https://x.xcute.workers.dev/api/upload \\
  -H "Content-Type: application/json" \\
  -d '{"url":"https://example.com/image.jpg"}'`}
          </Code>
          <Code title="200 OK">
{`{
  "status": true,
  "message": "Upload successful",
  "result": {
    "filename": "34a0e8f7bdc6.jpg",
    "url": "x.silentphantom-uploader.workers.dev/f/34a0e8f7bdc6.jpg",
    "mimetype": "image/jpeg",
    "size": 301441
  }
}`}
          </Code>
        </Section>

        <Section method="GET" path="/f/:filename" desc="Serve file dari edge dengan cache permanen." />

        <div className="panel p-5">
          <div className="label-mono mb-3">// limits</div>
          <ul className="text-sm space-y-1.5 font-mono">
              <li className="terminal-line">max size: 1000Tera per file</li>
            <li className="terminal-line">format: image, video, audio, pdf, doc, zip, text</li>
            <li className="terminal-line">filename: random, original tidak disimpan</li>
            <li className="terminal-line">retention: permanent</li>
          </ul>
        </div>
      </main>
    </div>
  );
}

function Section({ method, path, desc, children }: { method: string; path: string; desc?: string; children?: React.ReactNode }) {
  return (
    <section className="panel-strong p-6 space-y-4">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="tag-dark">{method}</span>
          <span className="font-mono text-base font-bold">{path}</span>
        </div>
        {desc && <p className="text-sm text-muted-foreground">{desc}</p>}
      </div>
      {children && <div className="space-y-3">{children}</div>}
    </section>
  );
}

function Code({ title, children }: { title: string; children: string }) {
  return (
    <div>
      <div className="label-mono mb-1.5">{title}</div>
      <pre className="bg-foreground text-background p-4 rounded-md text-xs font-mono overflow-x-auto whitespace-pre leading-relaxed">
{children}
      </pre>
    </div>
  );
}
