KIMZ SHOP — TEMPLATE TOKO ONLINE

Isi folder:
- index.html : struktur halaman
- style.css  : desain responsif
- script.js  : daftar produk dan fitur toko

CARA MEMBUKA DI HP (Android):
1. Unduh dan ekstrak KimzShop.zip.
2. Buka folder hasil ekstrak di Acode.
3. Buka index.html lalu pilih Preview / Open in browser.
4. Pastikan style.css dan script.js berada di folder yang sama.

CARA MENGATUR TOKO:
1. Buka script.js.
2. Cari ADMIN_WHATSAPP = "6281234567890".
3. Ganti dengan nomor WhatsApp admin kamu dalam format kode negara, tanpa tanda +.
4. Edit daftar produk di bagian KONFIGURASI TOKO. Harga berupa angka Rupiah.
5. Simpan, lalu muat ulang halaman.

FITUR YANG SUDAH ADA:
- Tampilan responsif untuk HP dan desktop
- Daftar produk dan kategori
- Pencarian produk
- Urutkan harga/nama
- Keranjang belanja, jumlah barang, hapus produk
- Total otomatis
- Nama pemesan dan ringkasan pesanan ke WhatsApp
- Tema terang/gelap
- Keranjang disimpan di browser
- FAQ dan bagian kontak admin

CATATAN:
Ini adalah template frontend. Tidak ada database/server, login admin, pembayaran otomatis, atau konfirmasi pembayaran otomatis. Data keranjang hanya tersimpan di browser yang digunakan. Pesanan dikirim ke WhatsApp setelah nomor admin diganti.
