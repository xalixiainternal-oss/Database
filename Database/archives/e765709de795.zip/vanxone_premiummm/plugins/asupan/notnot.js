// asupan/notnot — satu file: metadata + kode fitur (gabungan dari engine5/plugins/asupan/notnot.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "notnot",
  "command": [
    "notnot"
  ],
  "category": "asupan",
  "desc": "Fitur notnot",
  "usage": ".notnot",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __vx.plugin("asupan/notnot", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/notnot.js'
  const __vxExports = {};
  const handler = async (m, { sock, reply }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  
  	try {
  		const baseUrl = global.APIs?.kyzz;
  		const apiKey = global.APIKeys?.[baseUrl] || global.APIKeys?.kyzz;
  		const fallbackUrl = `${baseUrl}/api/asupan/notnot?apikey=${apiKey}`;
  
  		const data = await global.fetchApi('kyzz', '/api/asupan/notnot').catch(() => null);
  
  		let mediaUrl = fallbackUrl;
  		if (data) {
  			if (typeof data === 'string' && data.startsWith('http')) {
  				mediaUrl = data;
  			} else if (data.url) {
  				mediaUrl = data.url;
  			} else if (data.result) {
  				mediaUrl = typeof data.result === 'string' ? data.result : (data.result.url || data.result.link);
  			}
  		}
  
  		try {
  			await sock.sendMessage(m.chat, {
  				video: { url: mediaUrl },
  				caption: `🎥 *Asupan Notnot*\n\n© ${global.namaBot}`,
  				mimetype: 'video/mp4'
  			}, { quoted: m });
  		} catch {
  			await sock.sendMessage(m.chat, {
  				image: { url: mediaUrl },
  				caption: `📸 *Asupan Notnot*\n\n© ${global.namaBot}`
  			}, { quoted: m });
  		}
  
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } });
  
  	} catch (e) {
  		console.error('[ASUPAN NOTNOT ERROR]', e);
  		await sock.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
  		return reply('❌ Gagal mengambil asupan Notnot.');
  	}
  };
  
  handler.help = ['notnot'];
  handler.tags = ['asupan'];
  handler.command = ['notnot'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
