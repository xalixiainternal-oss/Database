// fitur tambahan × - vanXone </> (ai/termai-elevenlabs)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-elevenlabs", {"command":["elevenlabs","eleven","ttsel"],"category":"ai","desc":"Fitur elevenlabs <teks>","usage":".elevenlabs"})
