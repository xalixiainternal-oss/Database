// fitur tambahan × - vanXone </> (cek/cekjago)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjago", {"command":["cekjago"],"category":"cek","desc":"Fitur cekjago [@user]","usage":".cekjago"})
