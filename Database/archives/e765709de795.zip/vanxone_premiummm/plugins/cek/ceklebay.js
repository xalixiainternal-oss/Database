// fitur tambahan × - vanXone </> (cek/ceklebay)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklebay", {"command":["ceklebay"],"category":"cek","desc":"Fitur ceklebay [@user]","usage":".ceklebay"})
