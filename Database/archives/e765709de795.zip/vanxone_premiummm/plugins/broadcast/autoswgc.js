// fitur tambahan × - vanXone </> (jpm/autoswgc)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/autoswgc", {"command":["autoswgc"],"category":"broadcast","desc":"Fitur autoswgc","usage":".autoswgc","owner":true,"group":true})
