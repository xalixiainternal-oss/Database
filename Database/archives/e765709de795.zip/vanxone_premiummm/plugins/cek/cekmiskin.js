// fitur tambahan × - vanXone </> (cek/cekmiskin)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmiskin", {"command":["cekmiskin"],"category":"cek","desc":"Fitur cekmiskin [@user]","usage":".cekmiskin"})
