// fitur tambahan × - vanXone </> (cek/cekkacung)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkacung", {"command":["cekkacung"],"category":"cek","desc":"Fitur cekkacung [@user]","usage":".cekkacung"})
