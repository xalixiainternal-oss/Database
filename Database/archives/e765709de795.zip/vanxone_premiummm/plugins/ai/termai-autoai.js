// fitur tambahan × - vanXone </> (ai/termai-autoai)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-autoai", {"command":["autoai","aichat","resetaichat","clearsesichat"],"category":"ai","desc":"Fitur autoai on/off","usage":".autoai"})
