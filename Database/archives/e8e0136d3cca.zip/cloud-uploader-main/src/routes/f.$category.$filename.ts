import { createFileRoute } from "@tanstack/react-router";

const ALLOWED_CATEGORIES = new Set([
  "images",
  "videos",
  "audios",
  "documents",
  "archives",
  "others",
]);

export const Route = createFileRoute("/f/$category/$filename")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const owner = process.env.GITHUB_OWNER;
        const repo = process.env.GITHUB_REPO;
        const branch = process.env.GITHUB_BRANCH || "main";
        if (!owner || !repo) {
          return new Response("Not configured", { status: 500 });
        }

        const category = params.category.replace(/[^a-zA-Z0-9_-]/g, "");
        const safe = params.filename.replace(/[^a-zA-Z0-9._-]/g, "");
        if (!safe || !ALLOWED_CATEGORIES.has(category)) {
          return new Response("Not found", { status: 404 });
        }

        const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/Database/${category}/${safe}`;
        const upstream = await fetch(rawUrl);
        if (!upstream.ok) return new Response("Not found", { status: 404 });

        const headers = new Headers();
        const ct = upstream.headers.get("content-type");
        if (ct) headers.set("Content-Type", ct);
        const cl = upstream.headers.get("content-length");
        if (cl) headers.set("Content-Length", cl);
        headers.set("Cache-Control", "public, max-age=31536000, immutable");
        headers.set("Access-Control-Allow-Origin", "*");

        return new Response(upstream.body, { status: 200, headers });
      },
    },
  },
});
