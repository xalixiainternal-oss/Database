// fitur tambahan × - vanXone </> (cek/cekganteng)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekganteng", {"command":["cekganteng"],"category":"cek","desc":"Fitur cekganteng [@tag/nama]","usage":".cekganteng"})
