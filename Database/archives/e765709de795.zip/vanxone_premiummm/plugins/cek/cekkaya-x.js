// fitur tambahan × - vanXone </> (cek/cekkaya)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkaya", {"command":["cekkaya"],"category":"cek","desc":"Fitur cekkaya [@tag/nama]","usage":".cekkaya"})
