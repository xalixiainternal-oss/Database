// fitur tambahan × - vanXone </> (cek/cekcerdas)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcerdas", {"command":["cekcerdas"],"category":"cek","desc":"Fitur cekcerdas [@user]","usage":".cekcerdas"})
