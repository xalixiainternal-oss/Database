// fitur tambahan × - vanXone </> (cek/cekjahat)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjahat", {"command":["cekjahat"],"category":"cek","desc":"Fitur cekjahat [@user]","usage":".cekjahat"})
