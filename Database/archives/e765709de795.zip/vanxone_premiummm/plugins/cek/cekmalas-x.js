// fitur tambahan × - vanXone </> (cek/cekmalas)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekmalas", {"command":["cekmalas"],"category":"cek","desc":"Fitur cekmalas [@user]","usage":".cekmalas"})
