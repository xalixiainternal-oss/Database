// fitur tambahan × - vanXone </> (cek/cekowner)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekowner", {"command":["cekowner","ownerinfo"],"category":"cek","desc":"Fitur cekowner [@user]","usage":".cekowner","premium":true})
