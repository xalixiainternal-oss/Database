// fitur tambahan × - vanXone </> (cek/cekhumoris)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekhumoris", {"command":["cekhumoris"],"category":"cek","desc":"Fitur cekhumoris [@user]","usage":".cekhumoris"})
