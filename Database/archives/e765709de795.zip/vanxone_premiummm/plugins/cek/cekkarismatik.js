// fitur tambahan × - vanXone </> (cek/cekkarismatik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkarismatik", {"command":["cekkarismatik"],"category":"cek","desc":"Fitur cekkarismatik [@user]","usage":".cekkarismatik"})
