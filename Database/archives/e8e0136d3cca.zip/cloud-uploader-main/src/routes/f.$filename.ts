import { createFileRoute } from "@tanstack/react-router";

const CATEGORIES = ["images", "videos", "audios", "documents", "archives", "others"];

export const Route = createFileRoute("/f/$filename")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const owner = process.env.GITHUB_OWNER;
        const repo = process.env.GITHUB_REPO;
        const branch = process.env.GITHUB_BRANCH || "main";
        if (!owner || !repo) {
          return new Response("Not configured", { status: 500 });
        }
        const safe = params.filename.replace(/[^a-zA-Z0-9._-]/g, "");
        if (!safe) return new Response("Not found", { status: 404 });

        // Try direct (legacy flat layout) first, then each category folder
        const candidates = [
          `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/Database/${safe}`,
          ...CATEGORIES.map(
            (c) =>
              `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/Database/${c}/${safe}`,
          ),
        ];

        for (const rawUrl of candidates) {
          const upstream = await fetch(rawUrl);
          if (!upstream.ok) continue;

          const headers = new Headers();
          const ct = upstream.headers.get("content-type");
          if (ct) headers.set("Content-Type", ct);
          const cl = upstream.headers.get("content-length");
          if (cl) headers.set("Content-Length", cl);
          headers.set("Cache-Control", "public, max-age=31536000, immutable");
          headers.set("Access-Control-Allow-Origin", "*");

          return new Response(upstream.body, { status: 200, headers });
        }

        return new Response("Not found", { status: 404 });
      },
    },
  },
});
