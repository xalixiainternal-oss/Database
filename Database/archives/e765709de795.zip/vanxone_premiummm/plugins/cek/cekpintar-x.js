// fitur tambahan × - vanXone </> (cek/cekpintar)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpintar", {"command":["cekpintar"],"category":"cek","desc":"Fitur cekpintar [@tag/nama]","usage":".cekpintar"})
