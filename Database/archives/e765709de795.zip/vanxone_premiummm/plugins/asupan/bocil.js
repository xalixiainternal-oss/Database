// asupan/bocil — satu file: metadata + kode fitur (gabungan dari engine3/plugins/asupan/bocil.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "bocil",
  "command": [
    "bocil",
    "bocilvid"
  ],
  "category": "asupan",
  "desc": "Video bocil",
  "usage": ".bocil",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 10,
  "energi": 1,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/asupan").split('\\').join('/')
module.exports = __vx.plugin("asupan/bocil", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/bocil.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const axios = __vxDef(require("axios"));
  const fs = __vxDef(require("fs"));
  const path = __vxDef(require("path"));
  const { f } = require("../../lib/ext/src/lib/vanxone-http.js");
  const pluginConfig = {
      name: 'bocil',
      alias: ['bocilvid'],
      category: 'asupan',
      description: 'Video bocil',
      usage: '.bocil',
      example: '.bocil',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 10,
      energi: 1,
      isEnabled: true
  }
  
  function loadJsonData(filename) {
      try {
          const filePath = path.join(process.cwd(), 'src', 'tiktok', filename)
          if (fs.existsSync(filePath)) {
              return JSON.parse(fs.readFileSync(filePath, 'utf-8'))
          }
      } catch {}
      return []
  }
  
  async function handler(m, { sock }) {
      m.react('🕕')
      
      try {
          const data = loadJsonData('bocil.json')
          
          if (data.length === 0) {
              m.react('❌')
              return m.reply(`❌ Data tidak tersedia`)
          }
          
          const item = data[Math.floor(Math.random() * data.length)]
          
          await sock.sendMedia(m.chat, item.url, null, m, {
              type: 'video'
          })
          m.react('✅')
          
      } catch (error) {
          m.react('❌')
          m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> Video tidak ditemukan`)
      }
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
