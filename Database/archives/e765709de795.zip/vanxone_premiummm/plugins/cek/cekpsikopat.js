// fitur tambahan × - vanXone </> (cek/cekpsikopat)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpsikopat", {"command":["cekpsikopat","psikopat","psycho"],"category":"cek","desc":"Cek seberapa psikopat kamu","usage":".cekpsikopat"})
