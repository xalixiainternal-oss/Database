/*

€ Creator: Fanztzy
€ Friends: Al Luffy
€ Base: Tama Ryuichi

*/

global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6283161221812']
global.gambar = "https://img2.pixhost.to/images/8629/738864560_ochobot.jpg"