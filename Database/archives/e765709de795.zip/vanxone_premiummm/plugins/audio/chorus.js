// fitur tambahan × - vanXone </> (audio/chorus)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/chorus", {"command":["chorus"],"category":"audio","desc":"Fitur chorus","usage":".chorus"})
