// fitur tambahan × - vanXone </> (cek/cekintrovert)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekintrovert", {"command":["cekintrovert","introvert"],"category":"cek","desc":"Cek tingkat introvert kamu","usage":".cekintrovert"})
