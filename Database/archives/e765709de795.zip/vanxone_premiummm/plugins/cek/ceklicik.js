// fitur tambahan × - vanXone </> (cek/ceklicik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceklicik", {"command":["ceklicik"],"category":"cek","desc":"Fitur ceklicik [@user]","usage":".ceklicik"})
