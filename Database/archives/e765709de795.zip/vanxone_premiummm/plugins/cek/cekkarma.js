// fitur tambahan × - vanXone </> (cek/cekkarma)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekkarma", {"command":["cekkarma","karma"],"category":"cek","desc":"Cek tingkat karma kamu","usage":".cekkarma"})
