// cecan/china — satu file: metadata + kode fitur (gabungan dari engine5/plugins/cecan/china.js)
const __vx = require("../../lib/adapter/e5.js")
const __meta = {
  "name": "china",
  "command": [
    "china",
    "cecan-china"
  ],
  "category": "asupan",
  "desc": "Fitur china",
  "usage": ".china",
  "limit": true
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cecan").split('\\').join('/')
module.exports = __vx.plugin("cecan/china", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/china.js'
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxExports = {};
  const sendCecan = __vxDef(require("../../lib/ext/lib/scrape/cecan.js"));
  
  const handler = async (m, { sock, reply }) => {
  	await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => null);
  
  	try {
  		await sendCecan(sock, m, reply, 'China');
  		await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } }).catch(() => null);
  	} catch (e) {
  		console.error('[CECAN CHINA ERROR]:', e);
  		await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => null);
  		return reply('❌ Gagal mengambil gambar cecan China.');
  	}
  };
  
  handler.help = ['china'];
  handler.tags = ['cecan'];
  handler.command = ['china', 'cecan-china', 'cecanchina'];
  handler.limit = true;
  
  const __vxDefault = handler;
  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  return __vxExports
})
