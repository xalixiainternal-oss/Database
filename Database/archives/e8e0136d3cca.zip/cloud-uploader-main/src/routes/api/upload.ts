import { createFileRoute } from "@tanstack/react-router";
import { getRequestHost } from "@tanstack/react-start/server";

// Batas ukuran file maksimum (95 MB)
const MAX_SIZE = 95 * 1024 * 1024; // 95MB

const EXT_BY_MIME: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/svg+xml": "svg",
  "image/bmp": "bmp",
  "application/pdf": "pdf",
  "application/zip": "zip",
  "application/x-zip-compressed": "zip",
  "application/json": "json",
  "application/xml": "xml",
  "application/msword": "doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "application/vnd.ms-excel": "xls",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
  "application/vnd.ms-powerpoint": "ppt",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
  "audio/mpeg": "mp3",
  "audio/ogg": "ogg",
  "audio/wav": "wav",
  "audio/webm": "weba",
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/quicktime": "mov",
  "text/plain": "txt",
  "text/html": "html",
  "text/css": "css",
  "text/javascript": "js",
  "application/octet-stream": "bin",
};

function extFromMime(mime: string): string {
  if (EXT_BY_MIME[mime]) return EXT_BY_MIME[mime];
  const slash = mime.split("/")[1];
  return (slash || "bin").split(";")[0].split("+")[0] || "bin";
}

function categoryFromMime(mime: string): string {
  const m = mime.toLowerCase();
  if (m.startsWith("image/")) return "images";
  if (m.startsWith("video/")) return "videos";
  if (m.startsWith("audio/")) return "audios";
  if (m === "application/pdf") return "documents";
  if (
    m.includes("word") ||
    m.includes("excel") ||
    m.includes("spreadsheet") ||
    m.includes("powerpoint") ||
    m.includes("presentation") ||
    m.startsWith("text/")
  ) return "documents";
  if (m.includes("zip") || m.includes("rar") || m.includes("tar") || m.includes("7z") || m.includes("gzip"))
    return "archives";
  return "others";
}

function detectMimeFromMagic(buf: Uint8Array): string | null {
  if (buf.length < 4) return null;
  const b = buf;
  // JPEG
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  // PNG
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  // GIF
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return "image/gif";
  // WebP (RIFF....WEBP)
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
      b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  // PDF
  if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return "application/pdf";
  // ZIP / docx / xlsx
  if (b[0] === 0x50 && b[1] === 0x4b && (b[2] === 0x03 || b[2] === 0x05)) return "application/zip";
  // MP4 (ftyp at offset 4)
  if (b.length > 11 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70) return "video/mp4";
  // MP3 (ID3 or 0xFF FB)
  if ((b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return "audio/mpeg";
  return null;
}

function randomName(len = 6): string {
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((x) => x.toString(16).padStart(2, "0")).join("");
}

function humanSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(2)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(2)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + CHUNK)));
  }
  // btoa is available in Workers
  return btoa(bin);
}

async function uploadToGitHub(opts: {
  bytes: Uint8Array;
  filename: string;
  category: string;
  token: string;
  owner: string;
  repo: string;
  branch: string;
}) {
  const path = `Database/${opts.category}/${opts.filename}`;
  const url = `https://api.github.com/repos/${opts.owner}/${opts.repo}/contents/${path}`;
  const body = {
    message: `Upload ${opts.category}/${opts.filename}`,
    content: bytesToBase64(opts.bytes),
    branch: opts.branch,
  };
  const res = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${opts.token}`,
      "Content-Type": "application/json",
      "User-Agent": "ichika-uploader",
      Accept: "application/vnd.github+json",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Storage upload failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return path;
}

export const Route = createFileRoute("/api/upload")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
          },
        }),
      POST: async ({ request }) => {
        const cors = {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json",
        };
        const fail = (status: number, message: string) =>
          new Response(JSON.stringify({ status: false, message }), { status, headers: cors });

        try {
          const token = process.env.GITHUB_TOKEN;
          const owner = process.env.GITHUB_OWNER;
          const repo = process.env.GITHUB_REPO;
          const branch = process.env.GITHUB_BRANCH || "main";
          if (!token || !owner || !repo) {
            return fail(500, "Storage credentials not configured");
          }

          const ct = request.headers.get("content-type") || "";
          let bytes: Uint8Array;
          let mimetype = "application/octet-stream";

          if (ct.includes("multipart/form-data")) {
            const fd = await request.formData();
            const file = fd.get("file");
            if (!(file instanceof File)) return fail(400, "Field 'file' is required");
            if (file.size > MAX_SIZE) return fail(413, "File too large (max 4MB on Vercel Hobby — upgrade ke Pro untuk 100MB)");
            bytes = new Uint8Array(await file.arrayBuffer());
            mimetype = file.type || detectMimeFromMagic(bytes) || "application/octet-stream";
          } else if (ct.includes("application/json")) {
            const json = (await request.json()) as { url?: string };
            if (!json.url) return fail(400, "Field 'url' is required");
            let parsed: URL;
            try { parsed = new URL(json.url); }
            catch { return fail(400, "Invalid URL"); }
            if (!/^https?:$/.test(parsed.protocol)) return fail(400, "Only http/https URLs allowed");

            const remote = await fetch(parsed.toString());
            if (!remote.ok) return fail(400, `Failed to fetch URL (${remote.status})`);
            const len = Number(remote.headers.get("content-length") || 0);
            if (len && len > MAX_SIZE) return fail(413, "File too large (max 4MB on Vercel Hobby — upgrade ke Pro untuk 100MB)");
            const buf = new Uint8Array(await remote.arrayBuffer());
            if (buf.length > MAX_SIZE) return fail(413, "File too large (max 4MB on Vercel Hobby — upgrade ke Pro untuk 100MB)");
            bytes = buf;
            mimetype = remote.headers.get("content-type")?.split(";")[0] ||
                       detectMimeFromMagic(buf) || "application/octet-stream";
          } else {
            return fail(415, "Unsupported content-type. Use multipart/form-data or application/json");
          }

          // sniff fallback
          if (mimetype === "application/octet-stream") {
            mimetype = detectMimeFromMagic(bytes) || mimetype;
          }

          const ext = extFromMime(mimetype);
          const category = categoryFromMime(mimetype);
          const filename = `${randomName(6)}.${ext}`;
          await uploadToGitHub({ bytes, filename, category, token, owner, repo, branch });

          const host = getRequestHost();
          const proto = host.includes("localhost") ? "http" : "https";
          const publicUrl = `${proto}://${host}/f/${category}/${filename}`;

          const now = new Date();
          const pad = (n: number) => String(n).padStart(2, "0");
          const jakartaParts = new Intl.DateTimeFormat("en-GB", {
            timeZone: "Asia/Jakarta",
            year: "numeric", month: "2-digit", day: "2-digit",
            hour: "2-digit", minute: "2-digit", second: "2-digit",
            hour12: false,
          }).formatToParts(now).reduce<Record<string, string>>((acc, p) => {
            if (p.type !== "literal") acc[p.type] = p.value;
            return acc;
          }, {});
          const uploadedAtWIB = `${jakartaParts.year}-${jakartaParts.month}-${jakartaParts.day} ${jakartaParts.hour}:${jakartaParts.minute}:${jakartaParts.second} WIB`;

          return new Response(
            JSON.stringify({
              status: true,
              message: "Upload successful",
              result: {
                filename,
                category,
                path: `${category}/${filename}`,
                url: publicUrl,
                mimetype,
                extension: ext,
                size: bytes.length,
                sizeHuman: humanSize(bytes.length),
                owner: "kaylleno",
                uploadedAt: uploadedAtWIB,
                uploadedAtISO: now.toISOString(),
                timezone: "Asia/Jakarta (UTC+7)",
                expiresAt: "never",
                retention: "permanent",
                storage: "Cloud Object Storage",
                visibility: "public",
                anonymous: true,
                cdn: host,
              },
            }),
            { status: 200, headers: cors },
          );
        } catch (e) {
          console.error("Upload error:", e);
          return fail(500, e instanceof Error ? e.message : "Internal error");
        }
      },
    },
  },
});
