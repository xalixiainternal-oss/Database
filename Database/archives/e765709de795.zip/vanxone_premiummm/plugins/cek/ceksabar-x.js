// fitur tambahan × - vanXone </> (cek/ceksabar)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/ceksabar", {"command":["ceksabar"],"category":"cek","desc":"Fitur ceksabar [@user]","usage":".ceksabar"})
