// fitur tambahan × - vanXone </> (jpm/stopautojpm)
module.exports = require('../../lib/adapter/e9.js').plugin("jpm/stopautojpm", {"command":["stopautojpm"],"category":"broadcast","desc":"Fitur stopautojpm","usage":".stopautojpm","owner":true})
