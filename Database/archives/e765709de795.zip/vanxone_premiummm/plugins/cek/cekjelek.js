// fitur tambahan × - vanXone </> (cek/cekjelek)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjelek", {"command":["cekjelek"],"category":"cek","desc":"Fitur cekjelek [@user]","usage":".cekjelek"})
