// fitur tambahan × - vanXone </> (audio/robot)
module.exports = require('../../lib/adapter/e9.js').plugin("audio/robot", {"command":["robot"],"category":"audio","desc":"Fitur robot","usage":".robot"})
