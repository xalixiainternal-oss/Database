// fitur tambahan × - vanXone </> (cek/cekcantik)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekcantik", {"command":["cekcantik"],"category":"cek","desc":"Fitur cekcantik [@tag/nama]","usage":".cekcantik"})
