// fitur tambahan × - vanXone </> (cek/cekgenit)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekgenit", {"command":["cekgenit"],"category":"cek","desc":"Fitur cekgenit [@user]","usage":".cekgenit"})
