// fitur tambahan × - vanXone </> (cek/cekjomblo)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekjomblo", {"command":["cekjomblo"],"category":"cek","desc":"Fitur cekjomblo [@user]","usage":".cekjomblo"})
