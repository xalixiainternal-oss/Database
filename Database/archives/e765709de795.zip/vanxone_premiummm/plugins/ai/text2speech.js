// ai/text2speech — fitur tambahan (plugins.zip), disesuaikan untuk × - vanXone </>
const __vx = require("../../lib/adapter/e2.js")
const __meta = {
  "command": [
    "aitts",
    "text2speech"
  ],
  "category": "ai",
  "owner": false,
  "group": false,
  "admin": false,
  "botAdmin": false,
  "desc": "Fitur aitts",
  "usage": ".tts <teks>|<voice>"
}
const __vdir = __dirname.split('\\').join('/')
module.exports = __vx.plugin("vxnew/ai/text2speech", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + "/text2speech.js"
  const __vxDef = (m) => (m && m.__esModule ? m.default : m);
  const __vxImp = async (m) => { const r = require(m); return r && r.__esModule ? r : Object.assign({ default: r }, r) };
  const __vxExports = {};
  const axios = __vxDef(require("axios"));
  
  let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
      const API_KEY = global.apikey?.vxapi;
      if (!API_KEY || API_KEY === "MASUKAN_API_KEY_KAMU_DISINI") {
        return m.reply("❌ API Key vanXone API belum dikonfigurasi di config.js!");
      }
      let [teks, voice] = text.split('|');
      if (!teks) {
        return m.reply(`🤖 *Text To Speech*\n\nContoh penggunaan:\n${usedPrefix + command} Halo namaku bot|en-US-JennyNeural\n\n*Note:* Jika voice tidak diisi, otomatis pakai default (id-ID-ArdiNeural).`);
      }
      if (!voice) {
        voice = 'id-ID-ArdiNeural';
      }
      await m.react('⏳');
      const apiUrl = `${global.web}/api/ai/text2speech?apikey=${API_KEY}&text=${encodeURIComponent(teks.trim())}&voice=${encodeURIComponent(voice.trim())}`;
      const response = await axios.get(apiUrl, { timeout: 60000 });
      const data = response.data;
      
      let audioUrl = data.result?.audio_url || data.result?.url || data.data?.audio_url || data.data?.url || data.audio_url || data.result || data.data;
      if (typeof audioUrl === 'object' && audioUrl !== null) {
        audioUrl = audioUrl.audio_url || audioUrl.url || JSON.stringify(audioUrl);
      }
      
      if (!data.status || !audioUrl || typeof audioUrl !== 'string' || !audioUrl.startsWith('http')) {
        throw new Error(data.message || data.error || 'Gagal generate audio TTS');
      }
      
      await conn.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: 'audio/mpeg',
        ptt: true
      }, { quoted: m }).catch(e => m.reply("Gagal mengirim media, ini linknya: " + audioUrl));
      await m.react('✅');
    } catch (e) {
      console.error('TTS Error:', e);
      await m.react('❌');
      m.reply(`❌ Gagal: ${e.response?.data?.error || e.message || 'Terjadi kesalahan sistem'}`);
    }
  };
  
  handler.help = ['tts <teks>|<voice>'];
  handler.tags = ['ai'];
  handler.premium = true;
  handler.command = /^(aitts|text2speech|tts)$/i;
  handler.limit = 1;
  
  
  
  const __vxDefault = handler

  Object.defineProperty(__vxExports, "default", { enumerable: true, get: () => __vxDefault });
  for (const k of ['before', 'all']) { if (typeof __vxExports[k] === 'function' && typeof __vxDefault === 'function' && !__vxDefault[k]) __vxDefault[k] = __vxExports[k] }
  return __vxExports
})
