// cek/cekcupu — satu file: metadata + kode fitur (gabungan dari engine3/plugins/cek/cekcupu.js)
const __vx = require("../../lib/adapter/e3.js")
const __meta = {
  "name": "cekcupu",
  "command": [
    "cekcupu",
    "cupu",
    "noob"
  ],
  "category": "cek",
  "desc": "Cek tingkat kecupuan kamu",
  "usage": ".cekcupu <nama>",
  "owner": false,
  "group": false,
  "private": false,
  "premium": false,
  "admin": false,
  "botAdmin": false,
  "cooldown": 5,
  "energi": 0,
  "needs": {
    "apikeys": [],
    "scrapers": [],
    "assets": []
  }
}
const __vdir = require('path').join(__dirname, "../../lib/ext/plugins/cek").split('\\').join('/')
module.exports = __vx.plugin("cek/cekcupu", __meta, async function () {
  const __dirname = __vdir, __filename = __vdir + '/cekcupu.js'
  const __vxExports = {};
  const pluginConfig = {
      name: 'cekcupu',
      alias: ['cupu', 'noob'],
      category: 'cek',
      description: 'Cek tingkat kecupuan kamu',
      usage: '.cekcupu <nama>',
      example: '.cekcupu Budi',
      isOwner: false,
      isPremium: false,
      isGroup: false,
      isPrivate: false,
      cooldown: 5,
      energi: 0,
      isEnabled: true
  }
  
  async function handler(m) {
          const percent = Math.floor(Math.random() * 101)
      const mentioned = m.mentionedJid[0] || m.sender
                      
      let desc = ''
      if (percent >= 90) desc = 'CUPU PARAH! NOOB DETECTED! 🤡'
      else if (percent >= 70) desc = 'Masih newbie nih~ 😅'
      else if (percent >= 50) desc = 'Biasa aja lah 🤔'
      else if (percent >= 30) desc = 'Cukup jago! 💪'
      else desc = 'PRO PLAYER! GG! 🏆'
      
      let txt = mentioned === m.sender ? `Hai @${mentioned.split('@')[0]}
      
  Tingkat kecupuan kamu *${percent}%*
  \`\`\`${desc}\`\`\`` : `Kamu ingin ngecek tingkat kecupuan @${mentioned.split('@')[0]} yak? 
      
  Tingkat kecupuan dia sebesar *${percent}%*
  \`\`\`${desc}\`\`\``
      
      await m.reply(txt, { mentions: [mentioned] })
  }
  
  
  Object.defineProperty(__vxExports, "config", { enumerable: true, get: () => pluginConfig });
  Object.defineProperty(__vxExports, "handler", { enumerable: true, get: () => handler });
  return __vxExports
})
