// fitur tambahan × - vanXone </> (cek/cekpendendam)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpendendam", {"command":["cekpendendam"],"category":"cek","desc":"Fitur cekpendendam [@user]","usage":".cekpendendam"})
