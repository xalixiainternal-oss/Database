// fitur tambahan × - vanXone </> (cek/cekpemarah)
module.exports = require('../../lib/adapter/e9.js').plugin("cek/cekpemarah", {"command":["cekpemarah"],"category":"cek","desc":"Fitur cekpemarah [@user]","usage":".cekpemarah"})
