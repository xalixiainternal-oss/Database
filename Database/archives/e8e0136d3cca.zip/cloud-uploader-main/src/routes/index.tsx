import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";

export const Route = createFileRoute("/")({
  component: UploaderPage,
  head: () => ({
    meta: [
      { title: "SILENTPHANTOM — File Uploader" },
      { name: "description", content: "Anonymous file uploader. Drop. Get link. Done." },
    ],
  }),
});

type UploadResult = {
  filename: string;
  url: string;
  mimetype: string;
  size: number;
  category?: string;
  path?: string;
  extension?: string;
  sizeHuman?: string;
  owner?: string;
  uploadedAt?: string;
  uploadedAtISO?: string;
  timezone?: string;
  expiresAt?: string;
  retention?: string;
  storage?: string;
  visibility?: string;
  anonymous?: boolean;
  cdn?: string;
};

type FileJob = {
  id: string;
  name: string;
  size: number;
  status: "queued" | "uploading" | "waiting" | "done" | "error";
  progress: number;
  result?: UploadResult;
  error?: string;
};

const FORMATS = ["image", "video", "audio", "pdf", "docx", "xlsx", "zip", "txt"];

function UploaderPage() {
  const [dragOver, setDragOver] = useState(false);
  const [jobs, setJobs] = useState<FileJob[]>([]);
  const [urlInput, setUrlInput] = useState("");
  const [urlLoading, setUrlLoading] = useState(false);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [urlResult, setUrlResult] = useState<UploadResult | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const updateJob = useCallback((id: string, patch: Partial<FileJob>) => {
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, ...patch } : j)));
  }, []);

  const uploadOne = useCallback((job: FileJob, file: File) => {
    return new Promise<void>((resolve) => {
      updateJob(job.id, { status: "uploading", progress: 0 });
      const fd = new FormData();
      fd.append("file", file);
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/upload");
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) updateJob(job.id, { progress: Math.round((e.loaded / e.total) * 100) });
      };
      const finish = () => {
        try {
          const json = JSON.parse(xhr.responseText);
          if (json.status) {
            updateJob(job.id, { status: "waiting", progress: 100 });
            setTimeout(() => {
              updateJob(job.id, { status: "done", result: json.result });
              resolve();
            }, 1000);
          } else {
            updateJob(job.id, { status: "error", error: json.message || "Upload failed" });
            resolve();
          }
        } catch {
          const msg = xhr.status === 413 ? "File terlalu besar (max 95MB)." : `Upload failed (HTTP ${xhr.status})`;
          updateJob(job.id, { status: "error", error: msg });
          resolve();
        }
      };
      xhr.onload = finish;
      xhr.onerror = () => { updateJob(job.id, { status: "error", error: "Network error" }); resolve(); };
      xhr.send(fd);
    });
  }, [updateJob]);

  const uploadFiles = useCallback(async (files: File[]) => {
    if (!files.length) return;
    const newJobs: FileJob[] = files.map((f) => ({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: f.name,
      size: f.size,
      status: "queued",
      progress: 0,
    }));
    setJobs((prev) => [...newJobs, ...prev]);
    for (let i = 0; i < files.length; i++) {
      await uploadOne(newJobs[i], files[i]);
    }
  }, [uploadOne]);

  const uploadUrl = useCallback(async () => {
    if (!urlInput.trim()) return;
    setUrlError(null); setUrlResult(null); setUrlLoading(true);
    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: urlInput.trim() }),
      });
      let json: { status?: boolean; message?: string; result?: UploadResult } | null = null;
      try { json = await res.json(); } catch { /* */ }
      if (!json) {
        if (res.status === 413) throw new Error("File terlalu besar (max 95MB).");
        throw new Error(`Upload failed (HTTP ${res.status})`);
      }
      if (!json.status) throw new Error(json.message || "Upload failed");
      if (!json.result) throw new Error("Upload failed (no result)");
      await new Promise((r) => setTimeout(r, 1000));
      setUrlResult(json.result);
      setUrlInput("");
    } catch (e) {
      setUrlError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUrlLoading(false);
    }
  }, [urlInput]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setDragOver(false);
    const files = Array.from(e.dataTransfer.files || []);
    if (files.length) uploadFiles(files);
  };

  // Prevent browser from opening files when dropped anywhere on the page
  useEffect(() => {
    const prevent = (e: DragEvent) => { e.preventDefault(); };
    window.addEventListener("dragover", prevent);
    window.addEventListener("drop", prevent);
    return () => {
      window.removeEventListener("dragover", prevent);
      window.removeEventListener("drop", prevent);
    };
  }, []);

  const copy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const clearDone = () => setJobs((prev) => prev.filter((j) => j.status !== "done" && j.status !== "error"));

  const anyActive = jobs.some((j) => j.status === "uploading" || j.status === "waiting" || j.status === "queued");

  return (
    <div className="min-h-screen flex flex-col">
      {/* nav */}
      <header className="border-b border-border bg-background/90 backdrop-blur sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-foreground text-background grid place-items-center font-mono font-bold text-sm">
              SP
            </div>
            <div className="font-mono text-sm font-bold tracking-tight">
              SILENT<span className="text-muted-foreground">PHANTOM</span>
            </div>
          </Link>
          <nav className="flex items-center gap-2">
            <span className="tag hidden sm:inline-flex">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--success)]" />
              v1.0 · online
            </span>
            <Link to="/api/docs" className="tag-dark">api docs ↗</Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <div className="max-w-6xl mx-auto px-6 py-10 grid lg:grid-cols-[1fr_320px] gap-8">
          {/* LEFT: uploader */}
          <div className="space-y-6">
            <div>
              <div className="label-mono mb-3">// silentphantom · file relay</div>
              <h1 className="text-5xl sm:text-6xl font-bold tracking-tighter">
                Drop it.<br />
                <span className="text-muted-foreground">Get a link.</span>
              </h1>
              <p className="mt-4 text-muted-foreground max-w-md text-sm leading-relaxed">
                Anonymous file relay. No account, no tracking. Maks 95MB per file
                  — disimpan di Cloud.
              </p>
            </div>

            {/* dropzone */}
            <div
              onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); setDragOver(true); }}
              onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); e.dataTransfer.dropEffect = "copy"; setDragOver(true); }}
              onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); setDragOver(false); }}
              onDrop={onDrop}
              onClick={() => inputRef.current?.click()}
              className={`panel-strong p-8 cursor-pointer transition-all ${
                dragOver ? "translate-x-[2px] translate-y-[2px] shadow-[2px_2px_0_0_var(--foreground)]" : "hover:-translate-y-[1px]"
              }`}
            >
              <input
                ref={inputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => { const fs = Array.from(e.target.files || []); if (fs.length) uploadFiles(fs); e.target.value = ""; }}
              />
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                <div className="w-20 h-20 rounded-md bg-secondary border border-border grid place-items-center font-mono">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M12 3v12m0-12l-4 4m4-4l4 4M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2" />
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="font-mono text-xs label-mono mb-1">// drop zone</div>
                  <div className="text-2xl font-bold tracking-tight">Drag a file here</div>
                  <div className="text-sm text-muted-foreground mt-1">
                    or <span className="underline decoration-dotted">browse from disk</span> · max 95MB
                  </div>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {FORMATS.map((f) => (
                      <span key={f} className="tag">.{f}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* url upload */}
            <div className="panel p-5">
              <div className="label-mono mb-2">// or relay from url</div>
              <div className="flex gap-2">
                <input
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="flex-1 px-3 py-2.5 bg-secondary border border-border rounded-md font-mono text-sm focus:outline-none focus:border-foreground"
                  onKeyDown={(e) => { if (e.key === "Enter") uploadUrl(); }}
                />
                <button
                  onClick={uploadUrl}
                  disabled={urlLoading || !urlInput.trim()}
                  className="px-4 py-2.5 bg-foreground text-background font-mono text-sm rounded-md hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  fetch →
                </button>
              </div>
              {urlError && (
                <div className="mt-3 text-xs font-mono text-destructive">error: {urlError}</div>
              )}
              {urlResult && (
                <div className="mt-3 flex gap-2">
                  <input
                    readOnly
                    value={urlResult.url}
                    onClick={(e) => (e.target as HTMLInputElement).select()}
                    className="flex-1 px-3 py-2 bg-secondary border border-border rounded-md font-mono text-xs"
                  />
                  <button
                    onClick={() => copy("url", urlResult.url)}
                    className="px-3 py-2 bg-foreground text-background font-mono text-xs rounded-md"
                  >
                    {copiedId === "url" ? "✓" : "copy"}
                  </button>
                </div>
              )}
            </div>

            {/* jobs */}
            {jobs.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="label-mono">// queue · {jobs.length} file{jobs.length > 1 ? "s" : ""}</div>
                  {!anyActive && (
                    <button onClick={clearDone} className="text-xs font-mono underline decoration-dotted text-muted-foreground hover:text-foreground">
                      clear all
                    </button>
                  )}
                </div>
                {jobs.map((job) => (
                  <JobCard key={job.id} job={job} onCopy={(t) => copy(job.id, t)} copied={copiedId === job.id} />
                ))}
              </div>
            )}
          </div>

          {/* RIGHT: sidebar */}
          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <div className="panel p-5">
              <div className="label-mono mb-3">// system</div>
              <div className="space-y-2.5 font-mono text-xs">
                <Row k="status" v={<span className="text-[var(--success)]">operational</span>} />
                <Row k="region" v="edge · global" />
                <Row k="max size" v="95 MB" />
                <Row k="auth" v="anonymous" />
                <Row k="retention" v="permanent" />
              </div>
            </div>

            <div className="panel p-5">
              <div className="label-mono mb-3">// quick curl</div>
              <pre className="bg-foreground text-background p-3 rounded-md text-[11px] font-mono overflow-x-auto leading-relaxed">
{`curl -X POST \\
  /api/upload \\
  -F "file=@photo.jpg"`}
              </pre>
              <Link to="/api/docs" className="mt-3 inline-block text-xs font-mono underline decoration-dotted text-muted-foreground hover:text-foreground">
                full docs →
              </Link>
            </div>

            <div className="panel p-5 bg-foreground text-background">
              <div className="font-mono text-[10px] tracking-widest uppercase opacity-60 mb-2">// built by</div>
              <div className="font-bold text-lg">kayXD</div>
              <div className="text-xs opacity-70 mt-1">Ichika Multidevice ops</div>
              <div className="flex gap-2 mt-3">
                <a href="https://t.me/kaylleno" target="_blank" rel="noreferrer" className="text-[10px] font-mono px-2 py-1 border border-background/30 rounded hover:bg-background/10">tg</a>
                <a href="https://www.instagram.com/kayxydl" target="_blank" rel="noreferrer" className="text-[10px] font-mono px-2 py-1 border border-background/30 rounded hover:bg-background/10">ig</a>
                <a href="https://whatsapp.com/channel/0029VbA0PhgJP20zFljfUS0b" target="_blank" rel="noreferrer" className="text-[10px] font-mono px-2 py-1 border border-background/30 rounded hover:bg-background/10">wa</a>
              </div>
            </div>
          </aside>
        </div>
      </main>

      <footer className="border-t border-border mt-10 bg-background/80">
        <div className="max-w-6xl mx-auto px-6 py-5 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-muted-foreground">
          <div>© 2026 SILENTPHANTOM · all bytes pass through quietly</div>
          <div>Developer kaylleno </div>
        </div>
      </footer>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{k}</span>
      <span>{v}</span>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="label-mono mb-0.5">{label}</div>
      <div className="font-mono text-xs truncate">{value}</div>
    </div>
  );
}

function JobCard({ job, onCopy, copied }: { job: FileJob; onCopy: (text: string) => void; copied: boolean }) {
  const statusLabel: Record<FileJob["status"], string> = {
    queued: "queued",
    uploading: `uploading ${job.progress}%`,
    waiting: "finalizing...",
    done: "200 OK · done",
    error: `error: ${job.error || "failed"}`,
  };
  const statusColor =
    job.status === "done" ? "text-[var(--success)]" :
    job.status === "error" ? "text-destructive" :
    job.status === "waiting" ? "text-foreground" :
    "text-muted-foreground";

  const barWidth = job.status === "done" || job.status === "waiting" ? 100 : job.status === "error" ? 100 : job.progress;
  const barColor = job.status === "error" ? "bg-destructive" : job.status === "done" ? "bg-[var(--success)]" : "bg-foreground";

  return (
    <div className={`panel p-4 ${job.status === "done" ? "panel-strong" : ""}`}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="min-w-0 flex-1">
          <div className="font-mono text-sm font-bold truncate">{job.name}</div>
          <div className="font-mono text-[10px] text-muted-foreground mt-0.5">
            {(job.size / 1024).toFixed(1)} KB
          </div>
        </div>
        <span className={`font-mono text-[10px] tracking-widest uppercase whitespace-nowrap ${statusColor}`}>
          {statusLabel[job.status]}
        </span>
      </div>
      <div className="h-1 bg-secondary rounded overflow-hidden">
        <div className={`h-full ${barColor} transition-all duration-300`} style={{ width: `${barWidth}%` }} />
      </div>
      {job.status === "done" && job.result && (
        <div className="mt-3 space-y-3">
          <div className="flex gap-2">
            <input
              readOnly
              value={job.result.url}
              onClick={(e) => (e.target as HTMLInputElement).select()}
              className="flex-1 px-3 py-2 bg-secondary border border-border rounded-md font-mono text-[11px]"
            />
            <button
              onClick={() => onCopy(job.result!.url)}
              className="px-3 py-2 bg-foreground text-background font-mono text-xs rounded-md hover:opacity-90 min-w-[72px]"
            >
              {copied ? "✓" : "copy"}
            </button>
            <a
              href={job.result.url}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-2 border border-border rounded-md font-mono text-xs hover:bg-secondary"
            >
              open ↗
            </a>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 pt-3 border-t border-border font-mono text-[10px]">
            <Detail k="owner" v={job.result.owner || "kayllano"} />
            <Detail k="category" v={job.result.category || "—"} />
            <Detail k="size" v={job.result.sizeHuman || `${(job.result.size / 1024).toFixed(1)} KB`} />
            <Detail k="type" v={job.result.mimetype} />
            <Detail k="uploaded" v={job.result.uploadedAt || "—"} />
            <Detail k="expires" v={<span className="text-[var(--success)]">{job.result.expiresAt || "never"}</span>} />
            <Detail k="storage" v={job.result.storage || "GitHub"} />
            <Detail k="visibility" v={job.result.visibility || "public"} />
            <Detail k="anonymous" v={job.result.anonymous === false ? "no" : "yes"} />
          </div>
        </div>
      )}
    </div>
  );
}

function Detail({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-muted-foreground tracking-widest uppercase text-[9px]">{k}</div>
      <div className="truncate">{v}</div>
    </div>
  );
}
