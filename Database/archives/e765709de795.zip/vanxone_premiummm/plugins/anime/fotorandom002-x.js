// fitur tambahan × - vanXone </> (anime/fotorandom002)
module.exports = require('../../lib/adapter/e9.js').plugin("anime/fotorandom002", {"command":["fotorandom002"],"category":"anime","desc":"vanXone random image 💗","usage":".fotorandom002"})
