// fitur tambahan × - vanXone </> (ai/termai-filters)
module.exports = require('../../lib/adapter/e9.js').plugin("ai/termai-filters", {"command":["toanime","jadianime","toreal","jadinyata","imglarger","enlarger","enlarge","filter","filters"],"category":"ai","desc":"Fitur toanime","usage":".toanime","premium":true})
